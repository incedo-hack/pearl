import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { PublicService } from "./_services/public.service";
import { Router } from "@angular/router";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private publicservics:PublicService,private router:Router){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    //return true;
    //this.router.navigate(['/']);
    if(this.publicservics.getUserLoggedin()){
      return true;
    }else{
      this.router.navigate(['/login']);
    }
  }
}
