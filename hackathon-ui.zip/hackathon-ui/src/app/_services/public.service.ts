import { Injectable } from '@angular/core';

@Injectable()
export class PublicService {

  constructor() { }

  public userName:string;
  public selectedDevice = [];
  public loginTime = new Date();
  public currentpage:string;
  public isUserLoggedin:boolean = false;
  /**
   * setUser
   */
  public setUser(username) {
    this.userName = username;
    this.setUserLoggedin();
  }
  /**
   * getUser
   */
  public getUser() {
    return this.userName;
  }

  /**
   * setSelectedDevice
   */
  public setSelectedDevice(selectedDevice) {
    this.selectedDevice = selectedDevice;
  }

  /**
   * getSelectedDevice
   */
  public getSelectedDevice() {
    return this.selectedDevice;
  }

  /**
   * setLoginTime
   */
  public setLoginTime(newLogintime) {
    this.loginTime = newLogintime;
  }

  /**
   * getLoginTime
   */
  public getLoginTime() {
    return this.loginTime;
  }

  /**
   * setCurrentpage
   */
  public setCurrentpage(newpage) {
    this.currentpage = newpage;
  }
  /**
   * getCurrentpage
   */
  public getCurrentpage() {
    return this.currentpage;
  }
  /**
   * setUserLoggedin
   */
  public setUserLoggedin() {
    this.isUserLoggedin = true;
  }

  /**
   * getUserLoggedin
   */
  public getUserLoggedin() {
    return this.isUserLoggedin;
  }
}
