import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable()
export class ApiList {
    public static authentication="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/Authentication";
    public static getAllDevices="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllDeviceList";
    public static getAllDevicesStatusCount="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllDeviceStatusCount";
    public static getSelectedDeviceDetails="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetSelectedDeviceDetails";
    public static getSelectedDeviceAlerts="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetSelectedDeviceAlerts";
    public static getAllAlertCount="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllAlertCount";
    public static getAllAlerts="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllAlerts";
    public static getAnalyticsDataPCV="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAnalyticsDataPCV";
    public static GetAnalyticsDataSOCnSOH="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAnalyticsDataSOCnSOH";
    public static GetAnalyticsDataTH="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAnalyticsDataTH";
    public static interval=3000;
    public static GetDeviceCycleCount="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetDeviceCycleCount";
    public static UpdateConfigurationFactors="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/UpdateConfigurationFactors";
    public static getCountriesList="https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetCountriesList";

     constructor() { }
}