import { Injectable } from '@angular/core';
/*importing http dependency*/
import { Http, Headers, Response,URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class ApiService {

  /**********************************************************************
   ********** private urls for api request from LOCAL********************
   *********************************************************************/

private _dashboard_data_url = 'https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllDeviceList';
    private _alerts_data_url = 'https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/AlertNotification';

  /*private _getcpuusageurl = '../assets/data/cpuusagedata.json';
  private _getmemoryusageurl = '../assets/data/memoryusagedata.json';
  private _gethddusageurl = '../assets/data/hddusagedata.json';*/


/**************************************************************************
 **********private urls for api request from SERVER************************
 **************************************************************************/
 /*private _getcpuusageurl = 'http://10.11.199.13:8020/downstream/System/CPU_Usage';
 private _getmemoryusageurl = 'http://10.11.199.13:8020/downstream/System/Memory_Usage';
 private _gethddusageurl = 'http://10.11.199.13:8020/downstream/System/Disk_Usage';*/


 /***********************************************************************************
  ************   URL FOR PROXY CONFIG    *********************************************
  *************************************************************************************/
 /*private _getcpuusageurl = '/api/downstream/System/CPU_Usage';
 private _getmemoryusageurl = '/api/downstream/System/Memory_Usage';
 private _gethddusageurl = '/api/downstream/System/Disk_Usage';*/

  constructor(
    private http: Http
  ) { }

  //Method to get vm details
  getDashboardData(){
       let headers = new Headers();
       headers.append('Authorization', 'Basic ZHNhOmRzYQ==');
     const  body ={"UserName":"admin"}
        return this.http.post(this._dashboard_data_url,body).map(
          (response:Response) => response.json()
        );
  }
    //method to get alerts
    
    getAlerts(){
       let headers = new Headers();
        const body ={"UserName":"user1","DeviceID":"1000"}
       headers.append('Authorization', 'Basic ZHNhOmRzYQ==');
        return this.http.get(this._alerts_data_url,{headers:headers}).map(
          (response:Response) => response.json()
        );
  }
}
