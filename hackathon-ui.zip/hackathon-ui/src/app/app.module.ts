import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

/*importing modules for angular material*/
import {  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,} from '@angular/material';
import "hammerjs";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

/*custom module import*/
import { ModalModule } from "../ngx-modal";
import { FormsModule ,ReactiveFormsModule} from "@angular/forms";
import { RoutingModule }        from './app.route';
import { AppComponent } from './app.component';
import { GaugeModule } from '../ng2-gauge';

/*Import statements for services*/
import { ApiService } from "./_services/api.service";
import { PublicService } from "./_services/public.service";

/*custom plugin import import*/
import { AgmCoreModule } from '@agm/core';
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer';
import { TabsModule } from 'ngx-bootstrap';
import { NvD3Module  } from 'ng2-nvd3';
import { NgxGaugeModule } from 'ngx-gauge';
import { AmChartsModule } from "@amcharts/amcharts3-angular";
import { ChartsModule } from 'ng2-charts';

/*pipe import statements*/
	import { SearchPipe } from './_pipes/search.pipe';

/*import for auth guard*/
import { AuthGuard } from "./auth.guard";
/*Components import statement*/
import { AnalyticsComponent } from './Components/Analytics/analytics.component';
import { DashboardComponent } from './Components/Screens/E_dashboard/dashboard.component';
import { DeviceDetailsComponent } from './Components/Screens/E_devicedetails/device-details.component';
import { HelpComponent } from './help/help.component';
import { HomeComponent } from './Components/Common/home/home.component';
import { LoginComponent } from './Components/Screens/E_login/login.component';
import { FooterComponent } from './Components/Common/footer/footer.component';
import { NotificationsComponent } from './Components/Co-Screen/notifications/notifications.component';
import { HeaderComponent } from './Components/Common//header/header.component';
import { MasterComponent } from './Components/Screens/master/master.component';
import { ILoginComponent } from './Components/Screens/I_login/i-login.component';
import { IDashboardComponent } from './Components/Screens/I_dashboard/i-dashboard.component';

@NgModule({
  declarations: [
    SearchPipe,
    AppComponent,
    AnalyticsComponent,
    DashboardComponent,
    DeviceDetailsComponent,
    HelpComponent,
    HomeComponent,
    LoginComponent,
    FooterComponent,
    NotificationsComponent,
    HeaderComponent,
    MasterComponent,
    ILoginComponent,
    IDashboardComponent
  ],
  imports: [
      BrowserAnimationsModule,
      ChartsModule,
  AmChartsModule,
      NvD3Module,
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule,
    RoutingModule,
    GaugeModule,
    /*angular material imports*/
     MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
     AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBeMiufX0-7mpOnlyd0Q-vuLktyV4FMrOw'
    }),
    AgmJsMarkerClustererModule,
    TabsModule.forRoot(),
      NgxGaugeModule,
  ],
  providers: [
    ApiService,
    PublicService,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
