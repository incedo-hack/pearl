import { Component, OnInit } from '@angular/core';
import { ApiService } from "../../../_services/api.service";
import { PublicService } from "../../../_services/public.service";
import { SearchPipe } from "../../../_pipes/search.pipe";
import { ApiList } from "../../../_services/apiList.service"
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AmChartsService, AmChart } from '@amcharts/amcharts3-angular';
import * as $ from 'jquery';
import {Http,Response,Headers, RequestOptions} from '@angular/http';

@Component({
  selector: 'app-i-dashboard',
  templateUrl: './i-dashboard.component.html',
  styleUrls: ['./i-dashboard.component.css']
})
export class IDashboardComponent implements OnInit {

 search:string;
    clickedMarkerInfo:any;
  
  /*data for pie chart in Analysis page*/
  // SOH
  SOHLabels:string[] = ['Good', 'Bad', 'Average'];
  SOHChartData:number[] = [350, 450, 100];
  SOHChartType:string = 'doughnut';
 // SOC
  SOCLabels:string[] = ['Good', 'Bad', 'Average'];
  SOCChartData:number[] = [250, 1000, 300];
  SOCChartType:string = 'doughnut';

  /*sectors for gauge meter*/
  sectors = [{
  from: 70,
  to: 90,
  color: 'orange'
}, {
  from: 90,
  to: 100,
  color: 'red'
}];
 sectors1 = [{
  from: 70,
  to: 90,
  color: 'orange'
}, {
  from: 90,
  to: 100,
  color: 'red'
}];
 sectors2 = [{
  from: 200,
  to: 220,
  color: 'orange'
}, {
  from: 220,
  to: 240,
  color: 'red'
}];
selectedBattery:any=[];
      infoWindowOpened = null;

    grey:any="../assets/images/grey.png";
     green:any="../assets/images/green.png";
     red:any="../assets/images/red.png";
    orange:any="../assets/images/orange.png";
     
      gaugeType = "semi";
   powerValue = 545;
    powerLabel = "Power";
    powerAppendText = "KW";
   voltageValue = 485;
    voltageLabel = "Voltage";
    voltageAppendText = "KV";
    currentValue = 251;
    currentLabel = "Current";
    currentAppendText = "amp";
    private powerTimer:number;
    private powerChart:AmChart;
    private voltageTimer:number;
    private voltageChart:AmChart;
    private currentTimer:number;
    private currentChart:AmChart;
    private disabled:boolean=false;
    healthStatusCount:any=[];
   liveStatusCount:any=[];
    alertsCount:any;
  constructor(
    private _apiService:ApiService,
    private publicservice:PublicService,
    private router:Router,
    private AmCharts: AmChartsService,
     private http:Http
  ) {
     
    }
  google;
  dashboardobj = [];
  selectedobj = [];
  selecteddevice:string;
  labelOptions;
  iconurl;
  absclass=true;
//getDashboardData
  lat: number =12.9716;
  lng: number = 77.5946 ;
    public pieOptions: any;
     private chart2: AmChart;
     private chart3: AmChart;
    private chart4: AmChart;
     private chart5: AmChart;
         private chart6: AmChart;
     private pieTimer: number;
    averageData:any;
    avgPower:number;
     avgCurrent:number;
     avgVoltage:number;
    //coords:any=[];
   
  ngOnInit() {
  
            this.getAverageData();
    this._apiService.getDashboardData()
      .subscribe(resData => {
            this.dashboardobj = resData;
            
            //console.log(resData);       
        });
      this.getBatteryHealthAndChargeStatus();
      this.getAlertsCount();
    this.labelOptions = {
              
        };
    this.iconurl = '../assets/images/green-dot.png';
    /*jquery for changing the size of gauge*/
   /* $(document).ready(function () {
      $("ng-gauge>section.angular-gauge").css("width","150px");
    });*/
            /*const newHeight=document.getElementById("mapImage").offsetHeight;

    const newWidth =document.getElementById("mapImage").offsetWidth;
      console.log(newHeight)*/
      //this.coords = [[400, 200], [80, 300], [345, 80], [200, 100], [150, 150]];
      /*for(var i=0;i<coords.length;i++){
          coords[i][0]=coords[i][0] * (newWidth/800);
          coords[i][1]=coords[i][1] * (newHeight/500);
      }*/
         


/*$(coords).each(function(i){
    var pos = this;
    var dot = $('<img src="../../../../assets/images/sensor_red.png" height=25 width=25" />');
    dot.css({
        position: 'absolute',
        left: pos[0] + "px",
        top: pos[1] + "px",
        "object-fit":"contain"
    });
    dot.click(function(pos){
        alert("clicked");
    })
    $("#overlay-dots").append(dot);
});*/
     

    /*3d pie chart*/
    //pie chart
      this.chart2 = this.AmCharts.makeChart('SOCpie3D', this.makeOptions(this.makeRandomDataProvider()));
      this.chart3 = this.AmCharts.makeChart('SOHpie3D', this.makeOptions(this.makeRandomDataProvider()));
       /*this.chart4 = this.AmCharts.makeChart('batteryHealthStatus', this.makeOptions1(this.makeRandomDataProvider()));
      this.chart5 = this.AmCharts.makeChart('batteryChargeStatus', this.makeOptions1(this.makeRandomDataProvider()));
     this.chart6 = this.AmCharts.makeChart('alertsCount', this.makeOptions1(this.makeRandomDataProvider()));*/

      //power chart 
      /*this.powerChart=this.AmCharts.makeChart("powerGauge",this.makepowerGaugeOptions(this.makeRandomPowerDataProvider));
      this.powerTimer = setInterval(() => {
      
      this.AmCharts.updateChart(this.powerChart, () => {
        this.powerChart.dataProvider = this.makeRandomPowerDataProvider();
      });
    }, 1500);*/

     //voltage chart
      /*this.voltageChart=this.AmCharts.makeChart("voltageGauge",this.makeVoltageGaugeOptions(this.makeRandomVoltageDataProvider));
      this.voltageTimer = setInterval(() => {
      
      this.AmCharts.updateChart(this.voltageChart, () => {
        this.voltageChart.dataProvider = this.makeRandomVoltageDataProvider();
      });
    }, 1500);*/

     //current chart
     /* this.currentChart=this.AmCharts.makeChart("currentGauge",this.makeCurrentGaugeOptions(this.makeRandomCurrentDataProvider));
      this.currentTimer = setInterval(() => {
      
      this.AmCharts.updateChart(this.currentChart, () => {
        this.currentChart.dataProvider = this.makeRandomCurrentDataProvider();
      });
    }, 1500);*/

  }
    
    //get battery status and charge status
    getBatteryHealthAndChargeStatus(){
        const body={"UserName":this.publicservice.getUser()}
        this.http.post(ApiList.getAllDevicesStatusCount,body)
        .subscribe(data=>{
            const response = data.json();
           const healthStatus=response["BatteryHealthStatus"];
            this.liveStatusCount=response["BatteryChargerStatus"];
/*            for(var i=0;i<chargeStatus.length;i++){
                if(chargeStatus[i]["State"]!=="Unknown"){
                    this.liveStatusCount.push(chargeStatus[i])
                }
            }*/
            for(var i=0;i<healthStatus.length;i++){
                if(healthStatus[i]["State"]!=="None"){
                    this.healthStatusCount.push(healthStatus[i])
                }
            }
            this.chart4 = this.AmCharts.makeChart('batteryHealthStatus', this.makeOptions1(this.healthStatusCount));
      this.chart5 = this.AmCharts.makeChart('batteryChargeStatus', this.makeOptions1(this.liveStatusCount));
        },err=>{
            console.log(err);
        })
    }
    getAlertsCount(){
        const body={"UserName":this.publicservice.getUser()}
        this.http.post(ApiList.getAllAlertCount,body)
        .subscribe(data=>{
            const response =data.json();
            this.alertsCount=response["Alerts"];
                 this.chart6 = this.AmCharts.makeChart('alertsCount', this.makeOptions1(this.alertsCount));
        },err=>{
            console.log(err);
        })
    }
  getAverageData(){
    const Body = {"UserName":this.publicservice.getUser()}
    this.http.post(ApiList.getAllDevices,Body)
    .subscribe(data =>{
      var avgData = data.json();
      this.averageData = avgData;
      console.log(this.averageData);
      this.avgPower=this.averageData["Average_Power_W"];
      this.avgCurrent=this.averageData["Average_Current_A"];
      this.avgVoltage=this.averageData["Average_Voltage_V"];
      },
      err => {
        console.log(err);
      })
    }
 
    //powerGauge
   /* makepowerGaugeOptions(options) {
    return {
        "hideCredits":true,
      "theme": "none",
  "type": "gauge",
  "axes": [{
    "topTextFontSize": 15,
    "topTextYOffset": 30,
    "topTextColor":"#288E6E",
    "axisThickness": 2,
    "endValue": 100,
    "gridInside": true,
    "inside": true,
    "radius": "50%",
    "valueInterval": 25,
    "startAngle": -90,
    "endAngle": 90,
    "unit": "",
    "bandOutlineAlpha": 0,
    "bands": [{
      "color": "#EFEFE9",
      "endValue": 100,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }, {
        color:"#22C222",
      "endValue": 0,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    },{
                color:"#FFA500",

      "endValue": 0,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    },{
                color:"#FF0000",

      "endValue": 0,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }]
  }],
  "arrows": [{
    "alpha": 1,
    "innerRadius": "35%",
    "nailRadius": 0,
    "radius": "150%",
      "color":"red"
  }]
}
    };*/
   /* makeRandomPowerDataProvider(){
        var value = this.avgPower;
  this.powerChart.arrows[0].setValue(value);
  this.powerChart.axes[0].setTopText(value + "\nW");
  // adjust darker band to new value
         if(value <= 60){
          this.powerChart.axes[0].bands[1].color="#22C222";
          //this.powerChart.axes[0].topTextColor="#22C222";
        }
        else if(value > 60 && value <= 80){
          this.powerChart.axes[0].bands[1].color="#FFA500";
          //this.powerChart.axes[0].topTextColor="#FFA500";
        }
        else{
          this.powerChart.axes[0].bands[1].color="#FF0000";
          //this.powerChart.axes[0].topTextColor="#FF0000";
        }
  this.powerChart.axes[0].bands[1].setEndValue(value);
//                 if(value <= 60){
//                     this.powerChart.axes[0].bands[1].setEndValue(value);
//                     this.powerChart.axes[0].bands[2].setStartValue(value);
//                     this.powerChart.axes[0].bands[2].setEndValue(value);
//                     this.powerChart.axes[0].bands[3].setStartValue(value);
//                     this.powerChart.axes[0].bands[3].setEndValue(value);
//                               this.powerChart.axes[0].topTextColor="#22C222";
//
//                                      }
//       else if(value > 60 && value <= 80){
//                                this.powerChart.axes[0].bands[2].setEndValue(value);
//                                    this.powerChart.axes[0].bands[3].setStartValue(60);
//                                            this.powerChart.axes[0].bands[3].setEndValue(60);
//                                this.powerChart.axes[0].bands[1].setEndValue(60);
//                                this.powerChart.axes[0].bands[1].setStartValue(0);
//                                this.powerChart.axes[0].bands[2].setStartValue(60);
//                     this.powerChart.axes[0].topTextColor="#FFA500";
//
//                 }
//        else{
//            this.powerChart.axes[0].bands[3].setEndValue(value);
//             this.powerChart.axes[0].bands[1].setEndValue(60);
//                                this.powerChart.axes[0].bands[1].setStartValue(0);
//                                this.powerChart.axes[0].bands[2].setStartValue(60);
//                     this.powerChart.axes[0].bands[2].setEndValue(80);
//                                            this.powerChart.axes[0].bands[3].setStartValue(80);
//                      this.powerChart.axes[0].topTextColor="#FF0000";
//
//
//
//        }

        return this.makeRandomPowerDataProvider;
    };*/

     //voltage Chart
    /*  makeVoltageGaugeOptions(options) {
    return {
        "hideCredits":true,
      "theme": "none",
  "type": "gauge",
  "axes": [{
    "topTextFontSize": 15,
    "topTextYOffset": 30,
    //"topTextColor":"#288E6E",
    //"axisColor": "green",
    "axisThickness": 2,
    "endValue": 100,
    "gridInside": true,
    "inside": true,
    "radius": "50%",
    "valueInterval": 25,
    //"tickColor": "green",
    "startAngle": -90,
    "endAngle": 90,
    "unit": "",
      //color:"green",
    "bandOutlineAlpha": 0,
    "bands": [{
      "color": "#EFEFE9",
      "endValue": 100,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }, {
      "color": "#3cd3a3",
      "endValue": 0,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }]
  }],
  "arrows": [{
    "alpha": 1,
    "innerRadius": "35%",
    "nailRadius": 0,
    "radius": "150%",
      "color":"red"
  }]
}
    };*/
    /*makeRandomVoltageDataProvider(){
        var value = this.avgVoltage;
  this.voltageChart.arrows[0].setValue(value);
  this.voltageChart.axes[0].setTopText(value + "\nV");
  // adjust darker band to new value
        if(value <= 60){
          this.voltageChart.axes[0].bands[1].color="#22C222";
          //this.voltageChart.axes[0].topTextColor="#22C222";
        }
        else if(value > 60 && value <= 80){
          this.voltageChart.axes[0].bands[1].color="#FFA500";
          //this.voltageChart.axes[0].topTextColor="#FFA500";
        }
        else{
          this.voltageChart.axes[0].bands[1].color="#FF0000";
          //this.voltageChart.axes[0].topTextColor="#FF0000";
        }
  this.voltageChart.axes[0].bands[1].setEndValue(value);
        return this.makeRandomVoltageDataProvider;
    };
*/
       //current chart
    /*makeCurrentGaugeOptions(options) {
    return {
        "hideCredits":true,
      "theme": "none",
  "type": "gauge",
  "axes": [{
    "topTextFontSize": 15,
    "topTextYOffset": 30,
    //"topTextColor":"#288E6E",
    //"axisColor": "green",
    "axisThickness": 2,
    "endValue": 100,
    "gridInside": true,
    "inside": true,
    "radius": "50%",
    "valueInterval": 20,
    //"tickColor": "green",
    "startAngle": -90,
    "endAngle": 90,
    "unit": "",
      //color:"green",
    "bandOutlineAlpha": 0,
    "bands": [{
      "color": "#EFEFE9",
      "endValue": 100,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }, {
      "endValue": 0,
      "innerRadius": "105%",
      "radius": "140%",
      "gradientRatio": [-0.4, -0.4, -0.4, -0.4, -0.4, -0.4, 0, 0.1, 0.2, 0.1, 0, -0.2, -0.5],
      "startValue": 0
    }]
  }],
  "arrows": [{
    "alpha": 1,
    "innerRadius": "35%",
    "nailRadius": 0,
    "radius": "150%",
      "color":"red"
  }]
}
    };*/
    /*makeRandomCurrentDataProvider(){
        var value = this.avgCurrent;
  this.currentChart.arrows[0].setValue(value);
  this.currentChart.axes[0].setTopText(value + "\nA");
  // adjust darker band to new value
         if(value <= 60){
          this.currentChart.axes[0].bands[1].color="#22C222";
          //this.currentChart.axes[0].topTextColor="#22C222";
        }
        else if(value > 60 && value <= 80){
          this.currentChart.axes[0].bands[1].color="#FFA500";
          //this.currentChart.axes[0].topTextColor="#FFA500";
        }
        else{
          this.currentChart.axes[0].bands[1].color="#FF0000";
          //this.currentChart.axes[0].topTextColor="#FF0000";
        }
  this.currentChart.axes[0].bands[1].setEndValue(value);
        return this.makeRandomCurrentDataProvider;
    };*/

/*method for piechart*/
 makeOptions(dataProvider) {
   return {
      "labelsEnabled":false,
        "hideCredits":true,
        "marginTop": 0,
        "marginBottom": 0,
        "marginLeft": 5,
        "marginRight": 1,
        "pullOutRadius": 0,
      'type': 'pie',
      'theme': 'light',
      'dataProvider': dataProvider,
        "valueField": "Value",
  "titleField": "State",
         "colorField": "Color",
  "outlineAlpha": 0.4,
  "depth3D": 15,
        "legend":{
   	"position":"right",
    "autoMargins":false,
    "valueText":null,
    "markerSize":6,
    "marginRight":45,
    "marginLeft":10
  },
  "balloonText": "[[title]]<br><span style='font-size:12px;'><b>[[value]]</b> ([[percents]]%)</span>",
  "angle": 30,
      'export': {
        'enabled': true
      }
    };
  }
     makeRandomDataProvider() {
    const dataProvider = [{
    "state": "Good",
    "value": 10
  }, {
    "state": "Average",
    "value": 11
  }, {
    "state": "Need Attention",
    "value": 12
  } ]

    return dataProvider;
  }
  /*************************************************/
     makeOptions1(dataProvider) {
         console.log(dataProvider)
    return {
      "labelsEnabled":false,
        "hideCredits":true,
        "outlineColor":"",
        "marginTop": 0,
        "marginBottom": 0,
        "marginLeft": 5,
        "marginRight": 1,
        "pullOutRadius": 0,
      'type': 'pie',
      'theme': 'light',
      'dataProvider': dataProvider,
        "valueField": "Value",
  "titleField": "State",
         "colorField": "Color",
  "outlineAlpha": 0.4,
  "depth3D": 15,
        "legend":{
   	"position":"right",
    "autoMargins":true,
    "valueText":null,
    "markerSize":7,
    "markerType":"circle"
  },
  "balloonText": "[[title]]<br><span style='font-size:12px;'><b>[[value]]</b> ([[percents]]%)</span>",
  "angle": 30,
      'export': {
        'enabled': true
      }
    };
  }

/*select thr client*/
getClntName(marker,index){
 // console.log(this.dashboardobj[index]);
 this.selectedobj = marker;
 this.selecteddevice = this.dashboardobj[index].Name;
 /*set value in service*/
 this.publicservice.setSelectedDevice(this.selectedobj);
 /*redirect to device details page*/
  this.router.navigate(['devicedetails']);
}

/*mapp*/
    zoom: number = 8;

  mapClicked($event: MouseEvent) {
   
  }
  
  /*markerDragEnd(m: marker, $event: MouseEvent) {
    console.log('dragEnd', m, $event);
  }*/
  
     clickedMarker(infoWindow, index: number) {
console.log(infoWindow)
    if( this.infoWindowOpened ===  infoWindow)
      return;
      
    if(this.infoWindowOpened !== null)
      this.infoWindowOpened.close();
      
    this.infoWindowOpened = infoWindow;
  }
    
    showData(item, ind, event) {
         item.state = !item.state;
        var index = this.selectedBattery.indexOf(item);
        //var index=ind;
        if(item.state==true){
            this.selectedBattery.push(item);
        }
        else{
            this.selectedBattery.splice(index, 1);

        }
    }
    showDetails(item,i){
        this.clickedMarkerInfo=item; 
        console.log(this.clickedMarkerInfo);
    }
/*$("#checkAll").click(function () {
     $('input:checkbox').not(this).prop('checked', this.checked);
 });
}*/
     checkAll(ev) {
    this.dashboardobj.forEach(x => x.state = ev.checked);
         console.log(this.dashboardobj[0]);
         for(var i=0;i<this.dashboardobj.length;i++){
             if(this.dashboardobj[i]["state"]==true){
                 this.selectedBattery.push(this.dashboardobj[i]);
             }
             else{
                 this.selectedBattery.length=0;
             }
         }
         
         
  }

  isAllChecked() {
    return this.dashboardobj.every(_ => _.state);
  }
  /*events for pie chart for Analysis*/
  // events
 chartClicked(e:any):void {
    console.log(e);
  }
 
  chartHovered(e:any):void {
    console.log(e);
  }
    

}
