import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ApiService } from "../../../_services/api.service";
import { PublicService } from "../../../_services/public.service";
import {ApiList} from "../../../_services/apiList.service"
import {Http,Response,Headers, RequestOptions} from '@angular/http';

import {
    ReactiveFormsModule,
    FormsModule,
    FormGroup,
    FormControl,
    Validators,
    FormBuilder,
    AbstractControl, 
    ValidatorFn,
} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm:FormGroup;
    loginData:any;
    loading:boolean=true;
    initial:boolean=false;

  constructor(
    private router:Router,
    private publicservice:PublicService,
     private http:Http
    ) { }
  loginError:boolean = false;
  version:string = '1.0.0';
  url = "background1.jpg";
    private createForm(){
    this.loginForm = new FormGroup({
     // tslint:disable-next-line
     email: new FormControl(''),
     password: new FormControl(''),
   });
}
  ngOnInit() {
      this.createForm();
      this.loading=true;
  }

  /**Do Login */
    createAuthorizationHeader(headers: Headers) {
    headers.append("Content-Type", "application/json");
        headers.append("Access-Control-Allow-Origin","*");

  }  
login(){
    /*let username = formdata.username;
    let password = formdata.password;

    if (username == "test" && password == "test") {
      this.publicservice.setUser("test");
      this.publicservice.setLoginTime(new Date());
      this.router.navigate(['home/dashboard']);
      this.loginError=false;
    }else{
      this.loginError=true;
    }*/
    this.loading=false;
    this.initial=true;
    let headers=new Headers();
     this.createAuthorizationHeader(headers);
    const body={
"UserName": this.loginForm.value.email,
  "Password": this.loginForm.value.password
}
    console.log(headers);
    this.http.post(ApiList.authentication,body,{
        headers:headers
        })
      .subscribe(
      data => {
          this.loading=true;
          this.loginData=data.json();
          console.log(this.loginData);  
          if(this.loginData["Authentication_Status"]=="True"){
              this.publicservice.setUser(this.loginData["UserName"]);
              this.publicservice.setLoginTime(new Date());
              this.router.navigate(['home/dashboard']);
          }
          else{
              this.initial=false;
              this.loginError=true;
          }
          
      },err => {
    console.log("Error!: ",err);
           
}
  )
}
}
