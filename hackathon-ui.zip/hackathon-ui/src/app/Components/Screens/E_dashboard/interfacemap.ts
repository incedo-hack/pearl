export interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}