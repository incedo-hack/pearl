export interface IVMdata {
  name: string;
  ip: string;
  port: string;
  status: string;
}