import { Component, OnInit } from '@angular/core';
/*importing custom modules*/
import { Router, ActivatedRoute, Params } from '@angular/router';
import { PublicService } from "../../../_services/public.service";
import * as $ from 'jquery';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(
    private router:Router,
    private publicservice:PublicService,
    private http:Http
  ) { }
  version:string = '1.0.0';
  globalUser:string;
  logintime;
  currentPage:string;
  notifications:any;
  notCount:number;
  ngOnInit() {

    this.globalUser = this.publicservice.getUser();
    this.logintime = this.publicservice.getLoginTime();
    this.currentPage = this.publicservice.getCurrentpage();
            this.getNotifications();

   $(document).ready(function () {
              /* $("#sidebar").mCustomScrollbar({
                    theme: "minimal"
                });*/
                $('#dismiss, .overlay').on('click', function () {
                    $('#sidebar').removeClass('active');
                    $('.overlay').fadeOut();
                    /*$("agm-map").fadeIn();
                    $(".legendPosition").fadeIn();*/
                });

                $('#sidebarCollapse').on('click', function () {
                    /*$("agm-map").fadeOut(100);
                    $(".legendPosition").fadeOut(100);*/
                    $('#sidebar').addClass('active');
                    $('.overlay').fadeIn();
                    $('.collapse.in').toggleClass('in');
                    $('a[aria-expanded=true]').attr('aria-expanded', 'false');
                });
            });
  }

  //GetAllAlert method
  getNotifications(){
    const Body = {"UserName":"user1"};
    this.http.post("https://smartbattery.azurewebsites.net/SmartBattery/SBMgmt/GetAllAlerts",Body)
    .subscribe(data => {
      this.notifications = data.json();
      this.notCount = this.notifications.length;
        for(var i=0;i<this.notifications.length;i++){
            if(this.notifications[i]["Alert"]["PriorityType"]=="High"){
                this.notifications[i]["imgSrc"]="../../assets/images/danger_red.png";
                console.log(this.notifications[i]["imgSrc"])
            }
            else if(this.notifications[i]["Alert"]["PriorityType"]=="Low"){
                                this.notifications[i]["imgSrc"]="../../assets/images/danger_yellow.png";

            }
             else if(this.notifications[i]["Alert"]["PriorityType"]=="Medium"){
                                this.notifications[i]["imgSrc"]="../../assets/images/danger_orange.png";

            }
        }
    },
    err => {
      console.log(err);
    })
}

 

  /*logout function*/
  logout(bol){
    if (bol == true) {
      this.router.navigate(['login']);
    }
  }

/*making the links inactive*/
  stopProp(e){
    //alert(e);
    e.preventDefault();
  }

}
