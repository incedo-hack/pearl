import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { PublicService } from "../../../_services/public.service";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  version:string = '0.1';
  globalUser:string;
  logintime;
  constructor(
    private router:Router,
    private publicservice:PublicService
  ) { }

  ngOnInit() {
    this.globalUser = this.publicservice.getUser();
    this.logintime = this.publicservice.getLoginTime();
  }
  /*logout method*/
   logout(bol){
    if (bol == true) {
      this.router.navigate(['master']);
    }
  }
}
