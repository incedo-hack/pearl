import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders} from '@angular/core';

/*import statement for auth guard*/
import { AuthGuard } from './auth.guard';
/*components importing*/
import { HomeComponent } from './Components/Common/home/home.component';
import { DashboardComponent } from './Components/Screens/E_dashboard/dashboard.component';
import { HelpComponent } from './help/help.component';
import { LoginComponent } from './Components/Screens/E_login/login.component';
import { AnalyticsComponent } from './Components/Analytics/analytics.component';
import { DeviceDetailsComponent } from './Components/Screens/E_devicedetails/device-details.component';
import { MasterComponent } from './Components/Screens/master/master.component';
import { ILoginComponent } from './Components/Screens/I_login/i-login.component';
import { IDashboardComponent } from './Components/Screens/I_dashboard/i-dashboard.component';


const appRoutes: Routes = [
    { path: 'home',
       canActivate: [AuthGuard],
      component: HomeComponent,
        children: [
            { path: 'dashboard', component: DashboardComponent },
           { path: 'help', component: HelpComponent },
           { path: 'analytics', component: AnalyticsComponent }
        ]
	},
    { path: 'login', component: LoginComponent },
    {
      path: 'devicedetails',
  canActivate: [AuthGuard],
      component: DeviceDetailsComponent
    },
        { path: 'I_login', component: ILoginComponent },
    { path: 'I_dashboard', component: IDashboardComponent},

    { path: '**', redirectTo: 'master' },
    { path: ' ', component: MasterComponent },
    { path: 'master', component:MasterComponent },
];

export const RoutingModule = RouterModule.forRoot(appRoutes,{useHash: true});