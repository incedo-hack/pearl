System.register("ngx-modal/Modal", ["@angular/core"], function (exports_1, context_1) {
    var __moduleName = context_1 && context_1.id;
    var core_1, ModalHeader, ModalContent, ModalFooter, Modal;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            }
        ],
        execute: function () {
            ModalHeader = (function () {
                function ModalHeader() {
                }
                return ModalHeader;
            }());
            ModalHeader = __decorate([
                core_1.Component({
                    selector: "modal-header",
                    template: "<ng-content></ng-content>"
                })
            ], ModalHeader);
            exports_1("ModalHeader", ModalHeader);
            ModalContent = (function () {
                function ModalContent() {
                }
                return ModalContent;
            }());
            ModalContent = __decorate([
                core_1.Component({
                    selector: "modal-content",
                    template: "<ng-content></ng-content>"
                })
            ], ModalContent);
            exports_1("ModalContent", ModalContent);
            ModalFooter = (function () {
                function ModalFooter() {
                }
                return ModalFooter;
            }());
            ModalFooter = __decorate([
                core_1.Component({
                    selector: "modal-footer",
                    template: "<ng-content></ng-content>"
                })
            ], ModalFooter);
            exports_1("ModalFooter", ModalFooter);
            Modal = (function () {
                // -------------------------------------------------------------------------
                // Constructor
                // -------------------------------------------------------------------------
                function Modal() {
                    this.closeOnEscape = true;
                    this.closeOnOutsideClick = true;
                    this.hideCloseButton = false;
                    // -------------------------------------------------------------------------
                    // Outputs
                    // -------------------------------------------------------------------------
                    this.onOpen = new core_1.EventEmitter(false);
                    this.onClose = new core_1.EventEmitter(false);
                    this.onSubmit = new core_1.EventEmitter(false);
                    // -------------------------------------------------------------------------
                    // Public properties
                    // -------------------------------------------------------------------------
                    this.isOpened = false;
                    this.createBackDrop();
                }
                // -------------------------------------------------------------------------
                // Lifecycle Methods
                // -------------------------------------------------------------------------
                Modal.prototype.ngOnDestroy = function () {
                    document.body.className = document.body.className.replace(/modal-open\b/, "");
                    if (this.backdropElement && this.backdropElement.parentNode === document.body)
                        document.body.removeChild(this.backdropElement);
                };
                // -------------------------------------------------------------------------
                // Public Methods
                // -------------------------------------------------------------------------
                Modal.prototype.open = function () {
                    var _this = this;
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    if (this.isOpened)
                        return;
                    this.isOpened = true;
                    this.onOpen.emit(args);
                    document.body.appendChild(this.backdropElement);
                    window.setTimeout(function () { return _this.modalRoot.nativeElement.focus(); }, 0);
                    document.body.className += " modal-open";
                };
                Modal.prototype.close = function () {
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    if (!this.isOpened)
                        return;
                    this.isOpened = false;
                    this.onClose.emit(args);
                    document.body.removeChild(this.backdropElement);
                    document.body.className = document.body.className.replace(/modal-open\b/, "");
                };
                // -------------------------------------------------------------------------
                // Private Methods
                // -------------------------------------------------------------------------
                Modal.prototype.preventClosing = function (event) {
                    event.stopPropagation();
                };
                Modal.prototype.createBackDrop = function () {
                    this.backdropElement = document.createElement("div");
                    this.backdropElement.classList.add("modal-backdrop");
                    this.backdropElement.classList.add("fade");
                    this.backdropElement.classList.add("in");
                };
                return Modal;
            }());
            __decorate([
                core_1.Input(),
                __metadata("design:type", String)
            ], Modal.prototype, "modalClass", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", Boolean)
            ], Modal.prototype, "closeOnEscape", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", Boolean)
            ], Modal.prototype, "closeOnOutsideClick", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", String)
            ], Modal.prototype, "title", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", Object)
            ], Modal.prototype, "hideCloseButton", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", String)
            ], Modal.prototype, "cancelButtonLabel", void 0);
            __decorate([
                core_1.Input(),
                __metadata("design:type", String)
            ], Modal.prototype, "submitButtonLabel", void 0);
            __decorate([
                core_1.Output(),
                __metadata("design:type", Object)
            ], Modal.prototype, "onOpen", void 0);
            __decorate([
                core_1.Output(),
                __metadata("design:type", Object)
            ], Modal.prototype, "onClose", void 0);
            __decorate([
                core_1.Output(),
                __metadata("design:type", Object)
            ], Modal.prototype, "onSubmit", void 0);
            __decorate([
                core_1.ViewChild("modalRoot"),
                __metadata("design:type", core_1.ElementRef)
            ], Modal.prototype, "modalRoot", void 0);
            Modal = __decorate([
                core_1.Component({
                    selector: "modal",
                    template: "\n<div class=\"modal\" \n     tabindex=\"-1\"\n     role=\"dialog\"\n     #modalRoot\n     (keydown.esc)=\"closeOnEscape ? close() : 0\"\n     [ngClass]=\"{ in: isOpened, fade: isOpened }\"\n     [ngStyle]=\"{ display: isOpened ? 'block' : 'none' }\"\n     (click)=\"closeOnOutsideClick ? close() : 0\">\n    <div [class]=\"'modal-dialog ' + modalClass\" (click)=\"preventClosing($event)\">\n        <div class=\"modal-content\" tabindex=\"0\" *ngIf=\"isOpened\">\n            <div class=\"modal-header\">\n                <button *ngIf=\"!hideCloseButton\" type=\"button\" class=\"close\" data-dismiss=\"modal\" [attr.aria-label]=\"cancelButtonLabel || 'Close'\" (click)=\"close()\"><span aria-hidden=\"true\">&times;</span></button>\n                <h4 class=\"modal-title\" *ngIf=\"title\">{{ title }}</h4>\n                <ng-content select=\"modal-header\"></ng-content>\n            </div>\n            <div class=\"modal-body\">\n                <ng-content select=\"modal-content\"></ng-content>\n            </div>\n            <div class=\"modal-footer\">\n                <ng-content select=\"modal-footer\"></ng-content>\n                <button *ngIf=\"cancelButtonLabel\" type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" (click)=\"close()\">{{ cancelButtonLabel }}</button>\n                <button *ngIf=\"submitButtonLabel\" type=\"button\" class=\"btn btn-primary\" (click)=\"onSubmit.emit(undefined)\">{{ submitButtonLabel }}</button>\n            </div>\n        </div>\n    </div>\n</div>\n"
                }),
                __metadata("design:paramtypes", [])
            ], Modal);
            exports_1("Modal", Modal);
        }
    };
});
System.register("ngx-modal/RouteModal", ["@angular/core", "@angular/router"], function (exports_2, context_2) {
    var __moduleName = context_2 && context_2.id;
    var core_2, router_1, RouteModal;
    return {
        setters: [
            function (core_2_1) {
                core_2 = core_2_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }
        ],
        execute: function () {
            RouteModal = (function () {
                // -------------------------------------------------------------------------
                // Constructor
                // -------------------------------------------------------------------------
                function RouteModal(router, activatedRoute) {
                    this.router = router;
                    this.activatedRoute = activatedRoute;
                    this.closeOnEscape = true;
                    this.closeOnOutsideClick = true;
                    this.hideCloseButton = false;
                    // -------------------------------------------------------------------------
                    // Outputs
                    // -------------------------------------------------------------------------
                    this.onOpen = new core_2.EventEmitter(false);
                    this.onClose = new core_2.EventEmitter(false);
                    this.onSubmit = new core_2.EventEmitter(false);
                    this.isOpened = false;
                    this.createBackDrop();
                }
                // -------------------------------------------------------------------------
                // Lifecycle Methods
                // -------------------------------------------------------------------------
                RouteModal.prototype.ngOnInit = function () {
                    this.open();
                };
                RouteModal.prototype.ngOnDestroy = function () {
                    document.body.className = document.body.className.replace(/modal-open\b/, "");
                    if (this.backdropElement && this.backdropElement.parentNode === document.body)
                        document.body.removeChild(this.backdropElement);
                };
                // -------------------------------------------------------------------------
                // Public Methods
                // -------------------------------------------------------------------------
                RouteModal.prototype.open = function () {
                    var _this = this;
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    if (this.isOpened)
                        return;
                    this.isOpened = true;
                    this.onOpen.emit(args);
                    document.body.appendChild(this.backdropElement);
                    window.setTimeout(function () { return _this.modalRoot.nativeElement.focus(); }, 0);
                    document.body.className += " modal-open";
                };
                RouteModal.prototype.close = function () {
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    if (!this.isOpened)
                        return;
                    this.isOpened = false;
                    this.onClose.emit(args);
                    document.body.className = document.body.className.replace(/modal-open\b/, "");
                    if (this.cancelUrl) {
                        var navigationExtras = {};
                        if (this.cancelUrlExtras) {
                            if (this.cancelUrlExtras.relative) {
                                navigationExtras.relativeTo = this.activatedRoute;
                            }
                            navigationExtras = Object.assign(navigationExtras, this.cancelUrlExtras);
                        }
                        this.router.navigate(this.cancelUrl, navigationExtras);
                    }
                    else {
                        window.history.back();
                    }
                };
                // -------------------------------------------------------------------------
                // Private Methods
                // -------------------------------------------------------------------------
                RouteModal.prototype.preventClosing = function (event) {
                    event.stopPropagation();
                };
                RouteModal.prototype.createBackDrop = function () {
                    this.backdropElement = document.createElement("div");
                    this.backdropElement.classList.add("modal-backdrop");
                    this.backdropElement.classList.add("fade");
                    this.backdropElement.classList.add("in");
                };
                return RouteModal;
            }());
            __decorate([
                core_2.Input(),
                __metadata("design:type", Array)
            ], RouteModal.prototype, "cancelUrl", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", Object)
            ], RouteModal.prototype, "cancelUrlExtras", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", String)
            ], RouteModal.prototype, "modalClass", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", Boolean)
            ], RouteModal.prototype, "closeOnEscape", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", Boolean)
            ], RouteModal.prototype, "closeOnOutsideClick", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", String)
            ], RouteModal.prototype, "title", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", Object)
            ], RouteModal.prototype, "hideCloseButton", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", String)
            ], RouteModal.prototype, "cancelButtonLabel", void 0);
            __decorate([
                core_2.Input(),
                __metadata("design:type", String)
            ], RouteModal.prototype, "submitButtonLabel", void 0);
            __decorate([
                core_2.Output(),
                __metadata("design:type", Object)
            ], RouteModal.prototype, "onOpen", void 0);
            __decorate([
                core_2.Output(),
                __metadata("design:type", Object)
            ], RouteModal.prototype, "onClose", void 0);
            __decorate([
                core_2.Output(),
                __metadata("design:type", Object)
            ], RouteModal.prototype, "onSubmit", void 0);
            __decorate([
                core_2.ViewChild("modalRoot"),
                __metadata("design:type", core_2.ElementRef)
            ], RouteModal.prototype, "modalRoot", void 0);
            RouteModal = __decorate([
                core_2.Component({
                    selector: "route-modal",
                    template: "\n<div class=\"modal route-modal\" \n     tabindex=\"-1\"\n     role=\"dialog\"\n     #modalRoot\n     (keydown.esc)=\"closeOnEscape ? close() : 0\"\n     [ngClass]=\"{ in: isOpened, fade: isOpened }\"\n     [ngStyle]=\"{ display: isOpened ? 'block' : 'none' }\"\n     (click)=\"closeOnOutsideClick ? close() : 0\">\n    <div [class]=\"'modal-dialog ' + modalClass\" (click)=\"preventClosing($event)\">\n        <div class=\"modal-content\" tabindex=\"0\" *ngIf=\"isOpened\">\n            <div class=\"modal-header\">\n                <button *ngIf=\"!hideCloseButton\" type=\"button\" class=\"close\" data-dismiss=\"modal\" [attr.aria-label]=\"cancelButtonLabel || 'Close'\" (click)=\"close()\"><span aria-hidden=\"true\">&times;</span></button>\n                <h4 class=\"modal-title\" *ngIf=\"title\">{{ title }}</h4>\n                <ng-content select=\"modal-header\"></ng-content>\n            </div>\n            <div class=\"modal-body\">\n                <ng-content select=\"modal-content\"></ng-content>\n            </div>\n            <div class=\"modal-footer\">\n                <ng-content select=\"modal-footer\"></ng-content>\n                <button *ngIf=\"cancelButtonLabel\" type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" (click)=\"close()\">{{ cancelButtonLabel }}</button>\n                <button *ngIf=\"submitButtonLabel\" type=\"button\" class=\"btn btn-primary\" (click)=\"onSubmit.emit(undefined)\">{{ submitButtonLabel }}</button>\n            </div>\n        </div>\n    </div>\n</div>\n"
                }),
                __metadata("design:paramtypes", [router_1.Router,
                    router_1.ActivatedRoute])
            ], RouteModal);
            exports_2("RouteModal", RouteModal);
        }
    };
});
System.register("ngx-modal/index", ["ngx-modal/Modal", "ngx-modal/RouteModal", "@angular/core", "@angular/common"], function (exports_3, context_3) {
    var __moduleName = context_3 && context_3.id;
    var Modal_1, RouteModal_1, core_3, common_1, ModalModule;
    var exportedNames_1 = {
        "ModalModule": true
    };
    function exportStar_1(m) {
        var exports = {};
        for (var n in m) {
            if (n !== "default" && !exportedNames_1.hasOwnProperty(n)) exports[n] = m[n];
        }
        exports_3(exports);
    }
    return {
        setters: [
            function (Modal_1_1) {
                Modal_1 = Modal_1_1;
                exportStar_1(Modal_1_1);
            },
            function (RouteModal_1_1) {
                RouteModal_1 = RouteModal_1_1;
                exportStar_1(RouteModal_1_1);
            },
            function (core_3_1) {
                core_3 = core_3_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }
        ],
        execute: function () {
            ModalModule = (function () {
                function ModalModule() {
                }
                return ModalModule;
            }());
            ModalModule = __decorate([
                core_3.NgModule({
                    imports: [common_1.CommonModule],
                    declarations: [
                        Modal_1.Modal,
                        RouteModal_1.RouteModal,
                        Modal_1.ModalHeader,
                        Modal_1.ModalContent,
                        Modal_1.ModalFooter,
                    ],
                    exports: [
                        Modal_1.Modal,
                        RouteModal_1.RouteModal,
                        Modal_1.ModalHeader,
                        Modal_1.ModalContent,
                        Modal_1.ModalFooter,
                    ],
                })
            ], ModalModule);
            exports_3("ModalModule", ModalModule);
        }
    };
});
System.register("ngx-modal", ["ngx-modal/index"], function (exports_4, context_4) {
    var __moduleName = context_4 && context_4.id;
    function exportStar_2(m) {
        var exports = {};
        for (var n in m) {
            if (n !== "default") exports[n] = m[n];
        }
        exports_4(exports);
    }
    return {
        setters: [
            function (index_1_1) {
                exportStar_2(index_1_1);
            }
        ],
        execute: function () {
        }
    };
});
