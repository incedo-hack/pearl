export * from "./Modal";
export * from "./RouteModal";
export declare class ModalModule {
}
