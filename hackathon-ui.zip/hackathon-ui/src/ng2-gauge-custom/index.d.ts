export { GaugeModuleCustom } from './src/gauge.module';
export { GaugeComponent } from './src/gauge.component';
