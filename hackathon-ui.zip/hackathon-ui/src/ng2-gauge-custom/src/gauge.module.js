import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GaugeComponent } from './gauge.component';
var GaugeModuleCustom = (function () {
    function GaugeModuleCustom() {
    }
    GaugeModuleCustom.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [GaugeComponent],
                    exports: [GaugeComponent]
                },] },
    ];
    /** @nocollapse */
    GaugeModuleCustom.ctorParameters = function () { return []; };
    return GaugeModuleCustom;
}());
export { GaugeModuleCustom };
//# sourceMappingURL=gauge.module.js.map