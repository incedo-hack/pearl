import { OnInit, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { Sector, Line, RenderSector, Value, GaugeProps } from './shared/gauge.interface';
import { GaugeConfig } from './shared/config';
export declare class GaugeComponent implements OnInit, AfterViewInit, GaugeProps {
    private _renderer;
    gauge: ElementRef;
    arrow: ElementRef;
    start: number;
    end: number;
    max: number;
    sectors: Sector[];
    unit: string;
    showDigital: boolean;
    light: number;
    lightTheme: boolean;
    factor: number;
    config: GaugeConfig;
    Config: GaugeConfig;
    viewBox: string;
    scaleLines: Line[];
    scaleValues: Value[];
    sectorArcs: RenderSector[];
    radius: number;
    center: number;
    scaleFactor: number;
    private _end;
    private _input;
    constructor(_renderer: Renderer2);
    input: number;
    readonly arc: string;
    readonly gaugeRotationAngle: number;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /**
     * Calculate arc.
     */
    private _arc(start, end);
    /**
     * Get angle coordinates (Cartesian coordinates).
     */
    private _getAngleCoor(degrees);
    /**
     * Calculate/translate the user-defined sectors to arcs.
     */
    private _calculateSectors();
    /**
     * Update the position of the arrow based on the input.
     */
    private _updateArrowPos(input);
    /**
     * Rotate the gauge based on the start property. The CSS rotation, saves additional calculations with SVG.
     */
    private _rotateGauge();
    /**
     * Determine the scale factor (10^n number; i.e. if max = 9000 then scale_factor = 1000)
     */
    private _determineScaleFactor(factor?);
    /**
     * Determine the line frequency which represents after what angle we should put a line.
     */
    private _determineLineFrequency();
    /**
     * Checks whether the line (based on index) is big or small separator.
     */
    private _isSeparatorReached(idx, lineFrequency);
    /**
     * Creates the scale.
     */
    private _createScale();
    /**
     * Get the scale line color from the user-provided sectors definitions.
     */
    private _getScaleLineColor(alpha);
    /**
     * Add a scale line to the list that will be later rendered.
     */
    private _addScaleLine(sin, cos, higherEnd, lowerEnd, color);
    /**
     * Add a scale value.
     */
    private _addScaleValue(sin, cos, lowerEnd, alpha);
}
