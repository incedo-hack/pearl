export declare class GaugeModuleCustom {
}
