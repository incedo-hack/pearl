import { Component, Input, ViewChild, Renderer2, ViewEncapsulation } from '@angular/core';
import { Separator } from './shared/gauge.interface';
import { Config } from './shared/config';
import { validate } from './shared/validators';
var GaugeComponent = (function () {
    function GaugeComponent(_renderer) {
        this._renderer = _renderer;
        this.start = Config.DEF_START;
        this.end = Config.DEF_END;
        this.Config = Config;
        this.scaleLines = [];
        this.scaleValues = [];
    }
    Object.defineProperty(GaugeComponent.prototype, "input", {
        get: function () {
            return this._input;
        },
        set: function (val) {
            this._input = val;
            this._updateArrowPos(val);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GaugeComponent.prototype, "arc", {
        get: function () {
            return this._arc(0, this._end);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GaugeComponent.prototype, "gaugeRotationAngle", {
        get: function () {
            return this._end - this.end;
        },
        enumerable: true,
        configurable: true
    });
    GaugeComponent.prototype.ngOnInit = function () {
        validate(this);
        var width = Config.WIDTH + Config.ARC_STROKE;
        this.viewBox = "0 0 " + width + " " + width;
        this.radius = Config.WIDTH / 2;
        this.center = width / 2;
        this._end = this.end;
        if (this.start > this.end) {
            this._end += (360 - this.start);
        }
        else {
            this._end -= this.start;
        }
        this._updateArrowPos(this._input);
        this._calculateSectors();
        this.scaleFactor = this.factor || this._determineScaleFactor();
        this._createScale();
    };
    GaugeComponent.prototype.ngAfterViewInit = function () {
        this._rotateGauge();
    };
    /**
     * Calculate arc.
     */
    GaugeComponent.prototype._arc = function (start, end) {
        var largeArc = end - start <= 180 ? 0 : 1;
        var startCoor = this._getAngleCoor(start);
        var endCoor = this._getAngleCoor(end);
        return "M " + endCoor.x + " " + endCoor.y + " A " + this.radius + " " + this.radius + " 0 " + largeArc + " 0 " + startCoor.x + " " + startCoor.y;
    };
    /**
     * Get angle coordinates (Cartesian coordinates).
     */
    GaugeComponent.prototype._getAngleCoor = function (degrees) {
        var rads = (degrees - 90) * Math.PI / 180;
        return {
            x: (this.radius * Math.cos(rads)) + this.center,
            y: (this.radius * Math.sin(rads)) + this.center
        };
    };
    /**
     * Calculate/translate the user-defined sectors to arcs.
     */
    GaugeComponent.prototype._calculateSectors = function () {
        var _this = this;
        if (!this.sectors) {
            return;
        }
        this.sectors = this.sectors.map(function (s) {
            var ratio = _this._end / _this.max;
            s.from *= ratio;
            s.to *= ratio;
            return s;
        });
        this.sectorArcs = this.sectors.map(function (s) {
            return {
                path: _this._arc(s.from, s.to),
                color: s.color
            };
        });
    };
    /**
     * Update the position of the arrow based on the input.
     */
    GaugeComponent.prototype._updateArrowPos = function (input) {
        var pos = (this._end / this.max) * input;
        this._renderer.setStyle(this.arrow.nativeElement, 'transform', "rotate(" + pos + "deg)");
    };
    /**
     * Rotate the gauge based on the start property. The CSS rotation, saves additional calculations with SVG.
     */
    GaugeComponent.prototype._rotateGauge = function () {
        var angle = 360 - this.start;
        this._renderer.setStyle(this.gauge.nativeElement, 'transform', "rotate(-" + angle + "deg)");
    };
    /**
     * Determine the scale factor (10^n number; i.e. if max = 9000 then scale_factor = 1000)
     */
    GaugeComponent.prototype._determineScaleFactor = function (factor) {
        if (factor === void 0) { factor = 10; }
        // Keep smaller factor until 3X
        if (this.max / factor > 30) {
            return this._determineScaleFactor(factor * 10);
        }
        return factor;
    };
    /**
     * Determine the line frequency which represents after what angle we should put a line.
     */
    GaugeComponent.prototype._determineLineFrequency = function () {
        var separators = this.max / this.scaleFactor;
        var separateAtAngle = this._end / separators;
        var lineFrequency;
        // If separateAtAngle is not an integer, use its value as the line frequency.
        if (separateAtAngle % 1 !== 0) {
            lineFrequency = separateAtAngle;
        }
        else {
            lineFrequency = Config.INIT_LINE_FREQ * 2;
            for (lineFrequency; lineFrequency <= separateAtAngle; lineFrequency++) {
                if (separateAtAngle % lineFrequency === 0) {
                    break;
                }
            }
        }
        return lineFrequency;
    };
    /**
     * Checks whether the line (based on index) is big or small separator.
     */
    GaugeComponent.prototype._isSeparatorReached = function (idx, lineFrequency) {
        var separators = this.max / this.scaleFactor;
        var totalSeparators = this._end / lineFrequency;
        var separateAtIdx = totalSeparators / separators;
        if (idx % separateAtIdx === 0) {
            return Separator.Big;
        }
        else if (idx % (separateAtIdx / 2) === 0) {
            return Separator.Small;
        }
        return Separator.NA;
    };
    ;
    /**
     * Creates the scale.
     */
    GaugeComponent.prototype._createScale = function () {
        var accumWith = this._determineLineFrequency() / 2;
        var isAboveSuitableFactor = this.max / this.scaleFactor > 10;
        var placedVals = 0;
        for (var alpha = 0, i = 0; alpha >= (-1) * this._end; alpha -= accumWith, i++) {
            var lineHeight = Config.SL_NORM;
            var sepReached = this._isSeparatorReached(i, accumWith);
            // Set the line height based on its type
            switch (sepReached) {
                case Separator.Big:
                    placedVals++;
                    lineHeight = Config.SL_SEP;
                    break;
                case Separator.Small:
                    lineHeight = Config.SL_MID_SEP;
                    break;
            }
            // Draw the line
            var higherEnd = this.center - Config.ARC_STROKE - 2;
            var lowerEnd = higherEnd - lineHeight;
            var alphaRad = Math.PI / 180 * (alpha + 180);
            var sin = Math.sin(alphaRad);
            var cos = Math.cos(alphaRad);
            var color = this._getScaleLineColor(alpha);
            this._addScaleLine(sin, cos, higherEnd, lowerEnd, color);
            // Put a scale value
            if (sepReached === Separator.Big) {
                var isValuePosEven = placedVals % 2 === 0;
                var isLast = alpha <= (-1) * this._end;
                if (!(isAboveSuitableFactor && isValuePosEven && !isLast)) {
                    this._addScaleValue(sin, cos, lowerEnd, alpha);
                }
            }
        }
    };
    /**
     * Get the scale line color from the user-provided sectors definitions.
     */
    GaugeComponent.prototype._getScaleLineColor = function (alpha) {
        alpha *= (-1);
        var color = '';
        if (this.sectors) {
            this.sectors.forEach(function (s) {
                if (s.from <= alpha && alpha <= s.to) {
                    color = s.color;
                }
            });
        }
        return color;
    };
    /**
     * Add a scale line to the list that will be later rendered.
     */
    GaugeComponent.prototype._addScaleLine = function (sin, cos, higherEnd, lowerEnd, color) {
        this.scaleLines.push({
            from: {
                x: sin * higherEnd + this.center,
                y: cos * higherEnd + this.center
            },
            to: {
                x: sin * lowerEnd + this.center,
                y: cos * lowerEnd + this.center
            },
            color: color
        });
    };
    /**
     * Add a scale value.
     */
    GaugeComponent.prototype._addScaleValue = function (sin, cos, lowerEnd, alpha) {
        var val = Math.round(alpha * (this.max / this._end)) * (-1);
        var posMargin = Config.TXT_MARGIN * 2;
        // Use the multiplier instead of the real value, if above MAX_PURE_SCALE_VAL (i.e. 1000)
        if (this.max > Config.MAX_PURE_SCALE_VAL) {
            val /= this.scaleFactor;
            val = Math.round(val * 100) / 100;
            posMargin /= 2;
        }
        this.scaleValues.push({
            text: val.toString(),
            coor: {
                x: sin * (lowerEnd - posMargin) + this.center,
                y: cos * (lowerEnd - posMargin) + this.center
            }
        });
    };
    GaugeComponent.decorators = [
        { type: Component, args: [{
                    selector: 'ng-gauge-custom',
                    template: "\n    <section class=\"angular-gauge-custom\" [class.light]=\"lightTheme\">\n      <svg class=\"info\" [attr.viewBox]=\"viewBox\" xmlns=\"http://www.w3.org/2000/svg\">\n        <circle *ngIf=\"light\"\n          class=\"red-light\"\n          [class.on]=\"input >= light\"\n          [attr.cx]=\"center\"\n          [attr.cy]=\"Config.LIGHT_Y\"\n          [attr.r]=\"Config.LIGHT_RADIUS\">\n        </circle>\n        <text *ngIf=\"max > Config.MAX_PURE_SCALE_VAL\"\n          class=\"factor\"\n          [attr.x]=\"center\"\n          [attr.y]=\"Config.S_FAC_Y\">\n          x{{scaleFactor}} {{unit}}\n        </text>\n        <text *ngIf=\"showDigital\"\n          class=\"digital\"\n          [attr.x]=\"center\"\n          [attr.y]=\"Config.DIGITAL_Y\">\n          {{input}}\n        </text>\n        <text class=\"unit\" [attr.x]=\"center\" [attr.y]=\"Config.UNIT_Y\">{{unit}}</text>\n      </svg>\n      <svg #gauge [attr.viewBox]=\"viewBox\" xmlns=\"http://www.w3.org/2000/svg\">\n        <path class=\"main-arc\" [attr.d]=\"arc\" [attr.stroke-width]=\"Config.ARC_STROKE\" fill=\"none\" />\n        <path *ngFor=\"let arc of sectorArcs\"\n          [attr.d]=\"arc.path\"\n          [attr.stroke]=\"arc.color\"\n          [attr.stroke-width]=\"Config.ARC_STROKE\"\n          fill=\"none\" />\n        <line *ngFor=\"let line of scaleLines\"\n          [attr.stroke-width]=\"Config.SL_WIDTH\"\n          [attr.stroke]=\"line.color || (!lightTheme ? '#333' : '#fff')\"\n          [attr.x1]=\"line.from.x\"\n          [attr.y1]=\"line.from.y\"\n          [attr.x2]=\"line.to.x\"\n          [attr.y2]=\"line.to.y\" />\n        <text *ngFor=\"let val of scaleValues\"\n          class=\"text-val\"\n          dominant-baseline=\"central\"\n          [attr.x]=\"val.coor.x\"\n          [attr.y]=\"val.coor.y\"\n          [attr.transform]=\"'rotate(' + gaugeRotationAngle + ', ' + val.coor.x + ', ' + val.coor.y + ')'\">\n          {{val.text}}\n        </text>\n        <rect #arrow\n          class=\"arrow\"\n          [attr.x]=\"center - Config.ARROW_WIDTH / 2\"\n          [attr.y]=\"Config.ARROW_Y\"\n          [attr.height]=\"center - Config.ARROW_Y\"\n          [attr.width]=\"Config.ARROW_WIDTH\"\n          [attr.rx]=\"Config.ARROW_WIDTH / 2\"\n          [attr.ry]=\"Config.ARROW_WIDTH / 2\">\n        </rect>\n        <circle class=\"arrow-pin\" [attr.cx]=\"center\" [attr.cy]=\"center\" [attr.r]=\"Config.ARROW_PIN_RAD\" />\n      </svg>\n    </section>\n  ",
                    styles: ["\n    @font-face {\n      font-family: 'Orbitron';\n      font-style: normal;\n      font-weight: 700;\n      src: local('Orbitron Bold'), local('Orbitron-Bold'), url(https://fonts.gstatic.com/s/orbitron/v8/Y82YH_MJJWnsH2yUA5AuYY4P5ICox8Kq3LLUNMylGO4.woff2) format('woff2');\n      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215;\n    }\n\n    .angular-gauge-custom {\n      position: relative;\n width:150px !important; \n    }\n\n    .angular-gauge-custom svg.info {\n      position: absolute;\n      top: 0;\n      left: 0;\n    }\n\n    .angular-gauge-custom rect.arrow {\n      transform-origin: 50% 100%;\n      fill: orange;\n    }\n\n    .angular-gauge-custom text {\n      font-family: 'Orbitron', sans-serif;\n      font-weight: bold;\n      text-anchor: middle;\n      fill: #333;\n    }\n\n    .angular-gauge-custom.light text {\n      fill: #fff;\n    }\n\n    .angular-gauge-custom text.text-val {\n      font-size: 12px;\n    }\n\n    .angular-gauge-custom circle.arrow-pin {\n      fill: #333;\n    }\n\n    .angular-gauge-custom path.main-arc {\n      stroke: #333;\n    }\n\n    .angular-gauge-custom.light path.main-arc {\n      stroke: #fff;\n    }\n\n    .angular-gauge-custom text.factor {\n      font-size: 7px;\n    }\n\n    .angular-gauge-custom text.digital {\n      font-size: 16px;\n    }\n\n    .angular-gauge-custom text.unit {\n      font-size: 10px;\n    }\n\n    .angular-gauge-custom circle.red-light {\n      fill: #ff4f4f;\n      opacity: 0.1;\n    }\n\n    .angular-gauge-custom circle.red-light.on {\n      opacity: 1;\n    }\n\n  "],
                    encapsulation: ViewEncapsulation.None
                },] },
    ];
    /** @nocollapse */
    GaugeComponent.ctorParameters = function () { return [
        { type: Renderer2, },
    ]; };
    GaugeComponent.propDecorators = {
        'gauge': [{ type: ViewChild, args: ['gauge',] },],
        'arrow': [{ type: ViewChild, args: ['arrow',] },],
        'start': [{ type: Input },],
        'end': [{ type: Input },],
        'max': [{ type: Input },],
        'sectors': [{ type: Input },],
        'unit': [{ type: Input },],
        'showDigital': [{ type: Input },],
        'light': [{ type: Input },],
        'lightTheme': [{ type: Input },],
        'factor': [{ type: Input },],
        'config': [{ type: Input },],
        'input': [{ type: Input },],
    };
    return GaugeComponent;
}());
export { GaugeComponent };
//# sourceMappingURL=gauge.component.js.map