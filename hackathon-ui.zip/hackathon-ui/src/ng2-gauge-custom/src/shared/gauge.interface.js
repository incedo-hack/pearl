export var Separator;
(function (Separator) {
    Separator[Separator["NA"] = 0] = "NA";
    Separator[Separator["Big"] = 1] = "Big";
    Separator[Separator["Small"] = 2] = "Small";
})(Separator || (Separator = {}));
//# sourceMappingURL=gauge.interface.js.map