import { GaugeProps } from './gauge.interface';
export declare const validate: (props: GaugeProps) => void;
