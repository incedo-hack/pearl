export interface GaugeConfig {
    WIDTH: number;
    ARC_STROKE: number;
    ARROW_Y: number;
    ARROW_WIDTH: number;
    ARROW_PIN_RAD: number;
    SL_NORM: number;
    SL_MID_SEP: number;
    SL_SEP: number;
    SL_WIDTH: number;
    TXT_MARGIN: number;
    LIGHT_Y: number;
    LIGHT_RADIUS: number;
    S_FAC_Y: number;
    DIGITAL_Y: number;
    UNIT_Y: number;
    MAX_PURE_SCALE_VAL: number;
    INIT_LINE_FREQ: number;
    DEF_START: number;
    DEF_END: number;
}
export declare const Config: GaugeConfig;
