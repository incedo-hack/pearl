export declare class GaugeModule {
}
