import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GaugeComponent } from './gauge.component';
var GaugeModule = (function () {
    function GaugeModule() {
    }
    GaugeModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [GaugeComponent],
                    exports: [GaugeComponent]
                },] },
    ];
    /** @nocollapse */
    GaugeModule.ctorParameters = function () { return []; };
    return GaugeModule;
}());
export { GaugeModule };
//# sourceMappingURL=gauge.module.js.map