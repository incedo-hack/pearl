package org.MotoVibr.UserManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.MotoVibr.DataAccessLayer.DBQueries;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 * 
 * @author bhavya
 * 
 *         This class is responsible for all the user management
 *
 */
public class UserManagementDAOImpl implements UserManagementDAO {

	static final Logger logger = Logger.getLogger(UserManagementDAOImpl.class);

	/**
	 * This method checks if the registered user is being accessing the application
	 */
	public JSONObject authentication(Connection connection, String userName, String password) {
		logger.info("Query = " + DBQueries.Authentication);
		PreparedStatement stmt;
		JSONObject jsonobj = new JSONObject();
		try {
			jsonobj.put("UserName", userName);
			jsonobj.put("Authentication_Status", "False");
		} catch (JSONException e2) {
			logger.error(e2);
			e2.printStackTrace();
		}
		try {
			stmt = connection.prepareStatement(DBQueries.Authentication);
			stmt.setString(1, userName);
			stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
			logger.info(rs);
			while (rs.next()) {
				String name = rs.getString("UserName");
				logger.info("name =" + name);
				String password1 = rs.getString("Password");
				logger.info("password1 =" + password1);
				jsonobj.put("Authentication_Status", "True");
			}
		} catch (SQLException e) {
			logger.error(e);
		} catch (JSONException e) {
			logger.error(e);
		}
		logger.info("JSON obj returning = " + jsonobj);
		return jsonobj;
	}

	/**
	 * This method only verifies the username from DB
	 */
	public boolean checkForUser(Connection connection, String userName) {
		boolean deviceState = false;
		logger.info("Query = " + DBQueries.tblUserMasterOnUserName);
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(DBQueries.tblUserMasterOnUserName);
			stmt.setString(1, userName);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String name = rs.getString("UserName");
				logger.info("name =" + name);
				deviceState = true;
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return deviceState;
	}

	
	/**
	 * This method only verifies the username from DB
	 */
	public static boolean checkForUserID(Connection connection, int userID) {
		boolean user = false;
		logger.info("Query userid= " + DBQueries.tblAlertConfOnUserID);
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(DBQueries.tblAlertConfOnUserID);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String Email = rs.getString("Email");
				logger.info("Email =" + Email);
				user = true;
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return user;
	}
	
}