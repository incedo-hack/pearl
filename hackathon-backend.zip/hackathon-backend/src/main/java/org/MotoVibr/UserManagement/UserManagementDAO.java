package org.MotoVibr.UserManagement;

import java.sql.Connection;

import org.codehaus.jettison.json.JSONObject;

/**
 * 
 * @author bhavya
 *
 */
public interface UserManagementDAO {

	/**
	 * This method checks if the registered user is being accessing the application
	 * 
	 * @param connection
	 * @param userName
	 * @param password
	 * @return
	 */
	public JSONObject authentication(Connection connection, String userName, String password);

	/**
	 * This method only verifies the username from DB
	 * 
	 * @param connection
	 * @param userName
	 * @return
	 */
	public boolean checkForUser(Connection connection, String userName);

}
