package org.MotoVibr.Utilities;

import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

/**
 * this class is used to load the property file. it will be used across the
 * application
 */
public class Config {

	/*
	 * logger which will be used print the messages
	 */
	static final Logger logger = Logger.getLogger(Config.class);

	/*
	 * properties object which will be used to load the values from config file
	 */
	private static Properties defaultProps = new Properties();

	/*
	 * this block of code will be used to load the config properties file
	 */
	static {
		try {
			InputStream input = Config.class.getClassLoader().getResourceAsStream("config.properties");
			defaultProps.load(input);
			input.close();
		} catch (Exception e) {
			logger.error("Failed while loading the properties file", e);
		}
	}

	/**
	 * private constructor to hide the implicit one
	 */
	private Config() {

	}

	/**
	 *
	 * this method is used to get the value of particular key from the config file
	 * 
	 * @param fileName
	 * @param key
	 * @return String
	 */
	public static String getProperty(String key) {
		if (!StringUtils.isBlank(defaultProps.getProperty(key))) {
			return defaultProps.getProperty(key).trim();
		} else {
			logger.error("The property " + key + " is not available in config file");
			return defaultProps.getProperty(key);
		}
	}

}
