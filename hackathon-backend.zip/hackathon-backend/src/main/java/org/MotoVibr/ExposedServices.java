package org.MotoVibr;

import java.sql.Connection;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.MotoVibr.DataAccessLayer.DBConnection;
import org.MotoVibr.DeviceManagement.DeviceManagementDAOImpl;
import org.MotoVibr.InfoObject.AllAlertCount;
import org.MotoVibr.InfoObject.AllAlerts;
import org.MotoVibr.InfoObject.AllAlertsInfoObject;
import org.MotoVibr.InfoObject.AllDeviceListInfoObject;
import org.MotoVibr.InfoObject.AllDevicesStatusCount;
import org.MotoVibr.InfoObject.AnalyticsDataPCVInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataSOCnSOHInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataTHInfoObject;
import org.MotoVibr.InfoObject.AuthenticationInfoObject;
import org.MotoVibr.InfoObject.CycleCount;
import org.MotoVibr.InfoObject.DeviceInfoObject;
import org.MotoVibr.UserManagement.UserManagementDAOImpl;
import org.MotoVibr.InfoObject.ConfigurationFactors;
import org.MotoVibr.InfoObject.CountriesList;
import org.MotoVibr.InfoObject.UpdateConfig;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONObject;

/**
 * 
 * @author bhavya
 * 
 *         This is the service class. Methods return in this can be exposed as
 *         API's.
 *
 */
@Path("/MotoVibr")
public class ExposedServices {

	static final Logger logger = Logger.getLogger(ExposedServices.class);

	/*
	 * Object to access UserManagementDAOImpl methods
	 */
	UserManagementDAOImpl UserManagementDAOImpl = new UserManagementDAOImpl();
	/*
	 * Object to access DeviceManagementDAOImpl methods
	 */
	DeviceManagementDAOImpl deviceManagementDAOImpl = new DeviceManagementDAOImpl();

	/*
	 * DB connection
	 */
	DBConnection dbConnection = new DBConnection();
	Connection conn = dbConnection.getConnection();

	/**
	 * Service to check for the user with the password saved in DB.
	 * 
	 * @param auth
	 * @return String
	 */
	@POST
	@Path("/Authentication")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response validateAuthentication(AuthenticationInfoObject auth) {

		logger.info("DB connection = " + conn);
		JSONObject jsonObj = UserManagementDAOImpl.authentication(conn, auth.getUserName(), auth.getPassword());

		return Response.ok() // 200
				.entity(jsonObj.toString()).header("Access-Control-Allow-Origin", "*").build();

	}

	/**
	 * This service will return all the device details from DB.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/GetAllDeviceList")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response gatAllDevices(AuthenticationInfoObject auth) {

		logger.info("DB connection = " + conn);
		// check for valid user
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		logger.info("userValidation = " + userValidation);
		if (userValidation) {
			List<AllDeviceListInfoObject> deviceList = deviceManagementDAOImpl.getAllDevices(conn);
			return Response.ok() // 200
					.entity(deviceList).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid UserName").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	@GET
	@Path("/TestService")
	public Response testServices() {
		return Response.ok() // 200
				.entity("Success!").header("Access-Control-Allow-Origin", "*").build();
	}

	/**
	 * This service will return all the average values of the devices.
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetAllDeviceStatusCount")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response GetAllDeviceStatusCount(AuthenticationInfoObject auth) {

		logger.info("DB connection = " + conn);
		// check for valid user
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		logger.info("userValidation = " + userValidation);
		if (userValidation) {
			
			AllDevicesStatusCount deviceStatusCount = deviceManagementDAOImpl.getAllDevicesStatusCount(conn);
			return Response.ok() // 200
					.entity(deviceStatusCount).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid UserName").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	/**
	 * This API will list all the list all the device transaction for a device.
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetSelectedDeviceDetails")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getDeviceDetails(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				DeviceInfoObject deviceList = deviceManagementDAOImpl.GetSelectedDeviceDetails(conn, auth.getDeviceID());
				logger.info("deviceList");
				return Response.ok() // 200
						.entity(deviceList).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid UserName").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	/**
	 * This API will list all the alerts for a device
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetSelectedDeviceAlerts")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response alertNotification(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				List<AllAlertsInfoObject> alertList = deviceManagementDAOImpl.getAlertNotification(conn);
				logger.info(alertList);
				return Response.ok() // 200
						.entity(alertList).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	/**
	 * This API will list all the alerts.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/GetAllAlerts")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getAllAlerts(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		logger.info("userValidation = " + userValidation);
		if (userValidation) {
			List<AllAlerts> alertList = deviceManagementDAOImpl.getAllAlerts(conn);
			logger.info(alertList);
			return Response.ok() // 200
					.entity(alertList).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	/**
	 * This service will return all the alert counts.
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetAllAlertCount")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response GetGetAllAlertCount(AuthenticationInfoObject auth) {

		logger.info("DB connection = " + conn);
		// check for valid user
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		logger.info("userValidation = " + userValidation);
		if (userValidation) {
			
			AllAlertCount allAlertCount = deviceManagementDAOImpl.getAllAlertCount(conn);
			return Response.ok() // 200
					.entity(allAlertCount).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid UserName").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	/**
	 * This service will fetch entire Power,Current and Voltage values for a
	 * device
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetAnalyticsDataPCV")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getAnalyticsDataPCV(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				List<AnalyticsDataPCVInfoObject> analyticsDataPCVInfoObject = deviceManagementDAOImpl
						.getAnalyticsDataPCV(conn, auth.getDeviceID());
				return Response.ok() // 200
						.entity(analyticsDataPCVInfoObject).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	/**
	 * This service will fetch entire SOC and SOH values for a device
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetAnalyticsDataSOCnSOH")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getAnalyticsDataSOCnSOH(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				List<AnalyticsDataSOCnSOHInfoObject> analyticsDataSOCnSOHInfoObject = deviceManagementDAOImpl
						.getAnalyticsDataSOCnSOH(conn, auth.getDeviceID());
				return Response.ok() // 200
						.entity(analyticsDataSOCnSOHInfoObject).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}

	/**
	 * This service will fetch entire humidity and temperature values for a device
	 * 
	 * @param auth
	 * @return
	 */
	@POST
	@Path("/GetAnalyticsDataTH")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getAnalyticsDataTH(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				List<AnalyticsDataTHInfoObject> analyticsDataTHInfoObjectInfoObject = deviceManagementDAOImpl
						.getAnalyticsDataTH(conn, auth.getDeviceID());
				return Response.ok() // 200
						.entity(analyticsDataTHInfoObjectInfoObject).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	/**
	 * This API will return the battery cycle count.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/GetBatteryCycleCount")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getBatteryCycleCount(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
			CycleCount cycleCount = deviceManagementDAOImpl
					.getCycleCount(conn, auth.getDeviceID());
			logger.info(cycleCount);
			return Response.ok() // 200
					.entity(cycleCount).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	/**
	 * This API will return the Configuration.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/GetConfigurationFactors")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response getGetConfigurationFactors(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		if (userValidation) {
			boolean deviceIdExists = deviceManagementDAOImpl.checkForDevice(conn, auth.getDeviceID());
			if (deviceIdExists) {
				ConfigurationFactors configuration = deviceManagementDAOImpl
					.getConfigurationFactors(conn, auth.getDeviceID());
			logger.info(configuration);
			return Response.ok() // 200
					.entity(configuration).header("Access-Control-Allow-Origin", "*").build();
			} else {
				return Response.noContent().entity("Invalid DeviceId").header("Access-Control-Allow-Origin", "*")
						.build();
			}
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	
	/**
	 * This API will list all the alerts.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/GetCountriesList")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response GetCountriesList(AuthenticationInfoObject auth) {
		boolean userValidation = UserManagementDAOImpl.checkForUser(conn, auth.getUserName());
		logger.info("userValidation = " + userValidation);
		if (userValidation) {
			CountriesList countriesList = deviceManagementDAOImpl.getCountriesList(conn);
			logger.info(countriesList);
			return Response.ok() // 200
					.entity(countriesList).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	

	/**
	 * This API will list all the alerts.
	 * 
	 * @param auth
	 * @return Object
	 */
	@POST
	@Path("/UpdateConfigurationFactors")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN })
	public Response UpdateConfigurationFactors(UpdateConfig config) {
		boolean updateUserConfig = deviceManagementDAOImpl.getUserConfig(conn, config.getUserConfig(),config.getDeviceConfig(), config.getAlertConfig());
		logger.info("update user details =" + updateUserConfig);
		if (updateUserConfig) {
			return Response.ok() // 200
					.entity(updateUserConfig).header("Access-Control-Allow-Origin", "*").build();
		} else {
			return Response.noContent().entity("Invalid User").header("Access-Control-Allow-Origin", "*").build();
		}
	}
	
	
	
	
	
	
	
	
}
