package org.MotoVibr.Support;

/**
 * 
 * @author bhavya
 * 
 *         Enum for device Status
 *
 */
public enum DeviceProperties {

	Unknown, Active, InActive, Idle
}
