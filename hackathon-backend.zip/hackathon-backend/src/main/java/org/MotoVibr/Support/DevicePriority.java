package org.MotoVibr.Support;


/**
 * 
 * @author rahil
 * 
 *         Enum for device Status
 *
 */
public enum DevicePriority {
	
	Unknown,High,Medium,Low

}



