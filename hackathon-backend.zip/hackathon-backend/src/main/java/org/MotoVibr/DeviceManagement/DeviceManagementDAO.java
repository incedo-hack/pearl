package org.MotoVibr.DeviceManagement;

import java.sql.Connection;
import java.util.List;

import org.MotoVibr.InfoObject.AllAlerts;
import org.MotoVibr.InfoObject.AllAlertsInfoObject;
import org.MotoVibr.InfoObject.AllDeviceListInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataPCVInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataSOCnSOHInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataTHInfoObject;
import org.MotoVibr.InfoObject.DeviceInfoObject;

/**
 * 
 * @author bhavya
 * 
 *         This class includes all the methods which we need to retrieve from
 *         Device Master table.
 *
 */
public interface DeviceManagementDAO {

	/**
	 * This method will return all the saved devices
	 * 
	 * @param connection
	 * @return
	 */
	public List<AllDeviceListInfoObject> getAllDevices(Connection connection);

	/**
	 * This method will check if device exists or not.
	 * 
	 * @param connection
	 * @param deviceId
	 * @return
	 */
	public boolean checkForDevice(Connection connection, String deviceId);

	/**
	 * This method will return all the device details.
	 * 
	 * @param connection
	 * @return
	 */
	public DeviceInfoObject getDeviceDetails(Connection connection, String deviceId);

	/**
	 * This method will return the alerts for a device
	 * 
	 * @param connection
	 * @return
	 */
	public List<AllAlertsInfoObject> getAlertNotification(Connection connection);

	/**
	 * This method will return all the alerts.
	 * 
	 * @param connection
	 * @return
	 */
	public List<AllAlerts> getAllAlerts(Connection connection);

	/**
	 * This method will fetch power , current and voltage
	 * 
	 * @param connection
	 * @return
	 */
	public List<AnalyticsDataPCVInfoObject> getAnalyticsDataPCV(Connection connection, String devcieId);

	/**
	 * This service will fetch entire SOC and SOH values for a device
	 * 
	 * @param connection
	 * @param devcieId
	 * @return
	 */
	public List<AnalyticsDataSOCnSOHInfoObject> getAnalyticsDataSOCnSOH(Connection connection, String devcieId);

	/**
	 * This service will fetch entire humidity and temperature values for a device
	 * 
	 * @param connection
	 * @param devcieId
	 * @return
	 */
	public List<AnalyticsDataTHInfoObject> getAnalyticsDataTH(Connection connection, String devcieId);
}
