package org.MotoVibr.DeviceManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.MotoVibr.DataAccessLayer.DBQueries;
import org.MotoVibr.InfoObject.AlertInfoObject;
import org.MotoVibr.InfoObject.AlertStatusInfoObject;
import org.MotoVibr.InfoObject.AlertsInfo;
import org.MotoVibr.InfoObject.AllAlertCount;
import org.MotoVibr.InfoObject.AllAlerts;
import org.MotoVibr.InfoObject.BatteryStatusInfoObject;
import org.MotoVibr.InfoObject.CycleCount;
import org.MotoVibr.InfoObject.AllAlertsInfoObject;
import org.MotoVibr.InfoObject.AllDeviceDetailInfoObject;
import org.MotoVibr.InfoObject.AllDeviceListInfoObject;
import org.MotoVibr.InfoObject.AllDevicesStatusCount;
import org.MotoVibr.InfoObject.AnalyticsDataPCVInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataSOCnSOHInfoObject;
import org.MotoVibr.InfoObject.AnalyticsDataTHInfoObject;
import org.MotoVibr.InfoObject.BatteryChargerStatusInfoObject;
import org.MotoVibr.InfoObject.DeviceInfoObject;
import org.MotoVibr.InfoObject.LocationInfoObject;
import org.MotoVibr.InfoObject.SelcetedAlertInfo;
import org.MotoVibr.Support.DeviceProperties;
import org.MotoVibr.InfoObject.AlertConfig;
import org.MotoVibr.InfoObject.AlertConfiguration;
import org.MotoVibr.InfoObject.ConfigurationFactors;
import org.MotoVibr.InfoObject.Countries;
import org.MotoVibr.InfoObject.CountriesList;
import org.MotoVibr.InfoObject.DeviceConfig;
import org.MotoVibr.InfoObject.UserConfig;
import org.MotoVibr.UserManagement.UserManagementDAOImpl;
import org.apache.log4j.Logger;

/**
 * 
 * @author bhavya
 * 
 *         This class implements all the methods required for device management
 *
 */
public class DeviceManagementDAOImpl implements DeviceManagementDAO {

	static final Logger logger = Logger.getLogger(DeviceManagementDAOImpl.class);

	/**
	 * This method will return all the saved devices
	 */
	public List<AllDeviceListInfoObject> getAllDevices(Connection connection) {
		PreparedStatement stmt;
		List<AllDeviceListInfoObject> deviceList = new ArrayList<AllDeviceListInfoObject>();
		try {
			logger.info("Query = " + DBQueries.allTblDeviceMaster);
			stmt = connection.prepareStatement(DBQueries.allTblDeviceMaster);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				AllDeviceListInfoObject device = new AllDeviceListInfoObject();
				LocationInfoObject marker = new LocationInfoObject();

				String DeviceID = rs.getString("DeviceID").trim();
				logger.info("DeviceID =" + DeviceID);
				device.setDeviceID(DeviceID);
				String DeviceName = rs.getString("DeviceName");
				logger.info("DeviceName =" + DeviceName);
				device.setDeviceName(DeviceName);
				int Location_X = rs.getInt("DeviceLoc_X");
				logger.info("Location_X =" + Location_X);
				marker.setLocation_X(Location_X);
				int Location_Y = rs.getInt("DeviceLoc_Y");
				logger.info("Location_Y =" + Location_Y);
				marker.setLocation_Y(Location_Y);
				String Location = rs.getString("DeviceLocArea");
				logger.info("Location =" + Location);
				marker.setLocation(Location);
				int DeviceStatusDB = rs.getInt("DeviceStatus");
				logger.info("DeviceStatus =" + DeviceStatusDB);

				if (DeviceStatusDB == 0) {
					device.setDeviceStatus(DeviceProperties.Unknown);
				} else if (DeviceStatusDB == 1) {
					device.setDeviceStatus(DeviceProperties.Active);
				} else if (DeviceStatusDB == 2) {
					device.setDeviceStatus(DeviceProperties.InActive);
				} else if (DeviceStatusDB == 3) {
					device.setDeviceStatus(DeviceProperties.Idle);
				}
				
		PreparedStatement stmt2 = connection.prepareStatement(DBQueries.recentDataFromtblDeviceTransaction);
				stmt2.setString(1, DeviceID);

				ResultSet rs2 = stmt2.executeQuery();

				while (rs2.next()) {		
				String date = rs2.getString("DevicePacketTime");
					device.setDisplayTime(date);
					
				}
				device.setMarker(marker);

				deviceList.add(device);
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return deviceList;
	}

	
	
	public boolean checkForDevice(Connection connection, String deviceId) {
		boolean deviceExist = false;
		logger.info("Query = " + DBQueries.tblDeviceMasterOnDeviceId);
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(DBQueries.tblDeviceMasterOnDeviceId);
			stmt.setString(1, deviceId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String DeviceID = rs.getString("DeviceID");
				logger.info("DeviceID =" + DeviceID);
				deviceExist = true;
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return deviceExist;
	}

	/**
	 * This method will return all the device details.
	 */
	public DeviceInfoObject GetSelectedDeviceDetails(Connection connection, String deviceId) {
		PreparedStatement stmt;
		DeviceInfoObject device = new DeviceInfoObject();
		try {
			stmt = connection.prepareStatement(DBQueries.recentDataFromtblDeviceTransaction);
			stmt.setString(1, deviceId);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				LocationInfoObject marker = new LocationInfoObject();
				PreparedStatement stmt2 = connection.prepareStatement(DBQueries.tblDeviceMasterOnDeviceId);
				stmt2.setString(1, deviceId);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					String DeviceName = rs2.getString("DeviceName");
					logger.info("DeviceName =" + DeviceName);
					device.setDeviceName(DeviceName);
					int Current_Amp = rs.getInt("Current_Amp");
					logger.info("Current_Amp =" + Current_Amp);
					device.setCurrent_A(Current_Amp);
					int Voltage_Volt = rs.getInt("Voltage_Volt");
					logger.info("Voltage_Volt = " + Voltage_Volt);
					device.setVoltage_V(Voltage_Volt);
					int Power_Watt = rs.getInt("Power_Watt");
					logger.info("Power_Watt = " + Power_Watt);
					Date DeviceDisplayTime = rs.getDate("DeviceDisplayTime");
					logger.info("DeviceDisplayTime =" + DeviceDisplayTime);
					//device.setDisplayTime(new SimpleDateFormat("dd-MM-yyyy").format(DeviceDisplayTime));
					device.setDisplayTime(DeviceDisplayTime);
					// Average
					getAverage(connection, deviceId, device);

					// Marker
					int DeviceLoc_x = rs.getInt("DeviceLoc_X");
					logger.info("DeviceLoc_x =" + DeviceLoc_x);
					marker.setLocation_X(DeviceLoc_x);
					int Location_Y = rs.getInt("DeviceLoc_Y");
					logger.info("Longitude =" + Location_Y);
					marker.setLocation_Y(Location_Y);
					String Location = rs.getString("DeviceLocArea").trim();
					logger.info("Location =" + Location);
					marker.setLocation(Location);

					device.setMarker(marker);
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return device;
	}

	private void getAverage(Connection connection, String deviceId, DeviceInfoObject device) throws SQLException {
		AllDeviceDetailInfoObject device1 = new AllDeviceDetailInfoObject();
		PreparedStatement stmt3 = connection.prepareStatement(DBQueries.tblDeviceTransactionForADeviceOnAvg);
		stmt3.setString(1, deviceId);
		ResultSet rs3 = stmt3.executeQuery();
		while (rs3.next()) {
			int Average_Current_A = rs3.getInt("Average_Current_A");
			logger.info("Average_Current_A =" + Average_Current_A);
			device1.setAverage_Current_A(Average_Current_A);
			int Average_Voltage_V = rs3.getInt("Average_Voltage_V");
			logger.info("Average_Voltage_V = " + Average_Voltage_V);
			device1.setAverage_Voltage_V(Average_Voltage_V);
			int Average_Power_W = rs3.getInt("Average_Power_W");
			logger.info("Average_Power_W = " + Average_Power_W);
			device1.setAverage_Power_W(Average_Power_W);
		}
		device.setAverage(device1);
	}

	/**
	 * This method will return the alerts for a device
	 */
	public List<AllAlertsInfoObject> getAlertNotification(Connection connection) {
		PreparedStatement stmt;
		List<AllAlertsInfoObject> alertList = new ArrayList<AllAlertsInfoObject>();
		try {
			stmt = connection.prepareStatement(DBQueries.allTblAlertMaster);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				AllAlertsInfoObject alertListObj = new AllAlertsInfoObject();
				AlertInfoObject alert = new AlertInfoObject();
				SelcetedAlertInfo marker = new SelcetedAlertInfo();
				String AlertID = rs.getString("AlertID").trim();
				logger.info("AlertID =" + AlertID);
				PreparedStatement stmt2 = connection.prepareStatement(DBQueries.tblAlertTransactionOnAlertId);
				stmt2.setString(1, AlertID);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					String AlertName = rs.getString("AlertName");
					logger.info("AlertName =" + AlertName);
					alert.setName(AlertName);
					String AlertType = rs.getString("AlertType");
					logger.info("AlertType =" + AlertType);
					alert.setAlertType(AlertType);
					int PriorityType = rs.getInt("PriorityType");
					logger.info("PriorityType =" + PriorityType);
					if(PriorityType == 0) {
						alert.setPriorityType(org.MotoVibr.Support.DevicePriority.Unknown);
					}
					else if(PriorityType == 1) {
						alert.setPriorityType(org.MotoVibr.Support.DevicePriority.Low);
					}
					else if(PriorityType == 2) {
						alert.setPriorityType(org.MotoVibr.Support.DevicePriority.Medium);
					}
					else if(PriorityType == 3) {
						alert.setPriorityType(org.MotoVibr.Support.DevicePriority.High);
					}
					String AlertDescription = rs.getString("AlertDescription");
					logger.info("AlertDescription = " + AlertDescription);
					alert.setAlertDescription(AlertDescription);
					String OccuranceTime = rs2.getString("AlertPacketTime");
					logger.info("OccuranceTime = " + OccuranceTime);
					alert.setOccuranceTime(OccuranceTime);
					int X_Value = rs2.getInt("X_Value");
					logger.info("X_Value =" + X_Value);
					marker.setX_Value(X_Value);
					int Y_Value = rs2.getInt("Y_Value");
					logger.info("Y_Value =" + Y_Value);
					marker.setY_Value(Y_Value);
					int Z_Value = rs2.getInt("Z_Value");
					logger.info("Z_Value =" + Z_Value);
					marker.setZ_Value(Z_Value);
					int Temperature = rs2.getInt("Temperature");
					logger.info("Temperature =" + Temperature);
					marker.setTemprature(Temperature);
					int Voltage_Volt = rs2.getInt("Voltage_Volt");
					logger.info("Voltage_Volt =" + Voltage_Volt);
					marker.setVoltage_Volt(Voltage_Volt);
					int Power_Watt = rs2.getInt("Power_Watt");
					logger.info("Power_Watt =" + Power_Watt);
					marker.setPower_Watt(Power_Watt);
					int Current_Amp = rs2.getInt("Current_Amp");
					logger.info("Current_Amp =" + Current_Amp);
					marker.setCurrent_Amp(Current_Amp);
					int Humidity = rs2.getInt("Humidity");
					logger.info("Humidity =" + Humidity);
					marker.setHumidity(Humidity);

					alert.setMarker(marker);

					alertListObj.setAlert(alert);

					alertList.add(alertListObj);

				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return alertList;
	}

	/**
	 * This method will return all the alerts.
	 */
	public List<AllAlerts> getAllAlerts(Connection connection) {
		PreparedStatement stmt;
		List<AllAlerts> alertList = new ArrayList<AllAlerts>();
		try {
			stmt = connection.prepareStatement(DBQueries.tblAlertMasterOnAlertId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				
				AllAlerts alertListObj = new AllAlerts();
				AlertsInfo alert = new AlertsInfo();
					String DeviceID = rs.getString("DeviceID");
					logger.info("DeviceID =" + DeviceID);
					alertListObj.setDeviceID(DeviceID);
					String AlertName = rs.getString("AlertName");
					logger.info("AlertName =" + AlertName);
					alert.setAlertName(AlertName);
					String AlertType = rs.getString("AlertType");
					logger.info("AlertType =" + AlertType);
					alert.setAlertType(AlertType);
					int PriorityType = rs.getInt("PriorityType");
					logger.info("PriorityType =" + PriorityType);
					alert.setPriorityType(PriorityType);
					String AlertDescription = rs.getString("AlertDescription");
					logger.info("AlertDescription = " + AlertDescription);
					alert.setAlertDescription(AlertDescription);

					alertListObj.setAlert(alert);

					alertList.add(alertListObj);
				}
		} catch (SQLException e) {
			logger.error(e);
		}
		return alertList;
	}

	
	
	
	/**
	 * This method will return all the device status
	 */
	public AllDevicesStatusCount getAllDevicesStatusCount(Connection connection) {
		AllDevicesStatusCount battery = new AllDevicesStatusCount();
		try {
		
			
				
				PreparedStatement stmt3 = connection.prepareStatement(DBQueries.TotalNumberOfDevices);
				ResultSet rs3 = stmt3.executeQuery();
				while (rs3.next()) {
					int totalCount = rs3.getInt(1);
					battery.setTotalBatteryCount(totalCount);
				}
			
				
				PreparedStatement stmt1 = connection.prepareStatement(DBQueries.DeviceHealth);
				ResultSet rs1 = stmt1.executeQuery();
				
				List<BatteryStatusInfoObject> alertStatusInfoObjects = new ArrayList<BatteryStatusInfoObject>();
				while (rs1.next()) {
					
					BatteryStatusInfoObject batteryHealth = new BatteryStatusInfoObject();
					int deviceHealth = rs1.getInt("DeviceHealth");
					if(deviceHealth == 0) {
						batteryHealth.setState("None");
						batteryHealth.setValue(rs1.getInt(2));
						batteryHealth.setColor("");
					}
					else if(deviceHealth == 1) {
						batteryHealth.setState("Good");
						batteryHealth.setValue(rs1.getInt(2));
						batteryHealth.setColor("#00E405");
					}
					else if(deviceHealth == 2) {
						batteryHealth.setState("Average");
						batteryHealth.setValue(rs1.getInt(2));
						batteryHealth.setColor("#eda155");
					}
					else if(deviceHealth == 3) {
						batteryHealth.setState("Needs Attention");
						batteryHealth.setValue(rs1.getInt(2));
						batteryHealth.setColor("#F6020A");
					}
					alertStatusInfoObjects.add(batteryHealth);
					battery.setDeviceHealthStatus(alertStatusInfoObjects);
					
					PreparedStatement stmt2 = connection.prepareStatement(DBQueries.DeviceStatus);
					ResultSet rs2 = stmt2.executeQuery();
					
					List<BatteryChargerStatusInfoObject> batteryChargerStatusInfoObjects = new ArrayList<BatteryChargerStatusInfoObject>();
					while (rs2.next()) {
						
						BatteryChargerStatusInfoObject batteryChargerStatus = new BatteryChargerStatusInfoObject();
						int deviceStatus = rs2.getInt("DeviceStatus");
						if(deviceStatus == 0) {
							batteryChargerStatus.setState("Unknown");
							batteryChargerStatus.setValue(rs2.getInt(2));
							batteryChargerStatus.setColor("#0000FF");
						}
						else if(deviceStatus == 1) {
							batteryChargerStatus.setState("Active");
							batteryChargerStatus.setValue(rs2.getInt(2));
							batteryChargerStatus.setColor("#42f232");
						}
						else if(deviceStatus == 2) {
							batteryChargerStatus.setState("InActive");
							batteryChargerStatus.setValue(rs2.getInt(2));
							batteryChargerStatus.setColor("#eda155");
						}
						else if(deviceStatus == 3) {
							batteryChargerStatus.setState("Idle");
							batteryChargerStatus.setValue(rs2.getInt(2));
							batteryChargerStatus.setColor("#7F7F7F");
						}
						batteryChargerStatusInfoObjects.add(batteryChargerStatus);
						battery.setDeviceWorkingStatus(batteryChargerStatusInfoObjects);
					}
						
					
				}
				
				
				
				
		} catch (SQLException e) {
			logger.error(e);
		}

		return battery;
	}

	/**
	 * This method will return all the Alert count
	 */
	public AllAlertCount getAllAlertCount(Connection connection) {
		AllAlertCount alert = new AllAlertCount();
		try {
		
			
				
				PreparedStatement stmt3 = connection.prepareStatement(DBQueries.TotalAlertCount);
				ResultSet rs = stmt3.executeQuery();
				while (rs.next()) {
					int totalAlertCount = rs.getInt(1);
					alert.setTotalAlertCount(totalAlertCount);
				}
			
				
				PreparedStatement stmt1 = connection.prepareStatement(DBQueries.PriorityType);
				ResultSet rs1 = stmt1.executeQuery();
				
				List<AlertStatusInfoObject> alertStatusInfoObjects = new ArrayList<AlertStatusInfoObject>();
				while (rs1.next()) {
					
					AlertStatusInfoObject alertCount = new AlertStatusInfoObject();
					int alerts = rs1.getInt("PriorityType");
					if(alerts == 1) {
						alertCount.setState("High Priority");
						alertCount.setValue(rs1.getInt(2));
						alertCount.setColor("#F6020A");
						
					}
					else if(alerts == 2) {
						alertCount.setState("Medium Priority");
						alertCount.setValue(rs1.getInt(2));
						alertCount.setColor("#eda155");
						
					}
					else if(alerts == 3) {
						alertCount.setState("Low Priority");
						alertCount.setValue(rs1.getInt(2));
						alertCount.setColor("#FFC502");
						
					}
					
					alertStatusInfoObjects.add(alertCount);
					alert.setAlerts(alertStatusInfoObjects);
					
				
				}
					
				
			
			
			
			
			
	} catch (SQLException e) {
		logger.error(e);
	}

	return alert;
}
					
	public List<AnalyticsDataPCVInfoObject> getAnalyticsDataPCV(Connection connection, String devcieId) {
		PreparedStatement stmt;
		List<AnalyticsDataPCVInfoObject> analyticsDataPCVInfoObjectList = new ArrayList<AnalyticsDataPCVInfoObject>();
		try {
			stmt = connection.prepareStatement(DBQueries.descOrderedtblDeviceTransaction);
			stmt.setString(1, devcieId);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				AnalyticsDataPCVInfoObject analyticsDataPCVInfoObject = new AnalyticsDataPCVInfoObject();

				Date DateTime = rs.getDate("DeviceDisplayTime");
				logger.info("DeviceID =" + DateTime);
				analyticsDataPCVInfoObject.setDateTime(new SimpleDateFormat("dd-MM-yyyy").format(DateTime));
				int Current_A = rs.getInt("Current_Amp");
				logger.info("Current_A = " + Current_A);
				analyticsDataPCVInfoObject.setCurrent_A(Current_A);
				int Power_W = rs.getInt("Power_Watt");
				logger.info("Power_W = " + Power_W);
				analyticsDataPCVInfoObject.setPower_W(Power_W);
				int Voltage_V = rs.getInt("Voltage_Volt");
				logger.info("Voltage_V = " + Voltage_V);
				analyticsDataPCVInfoObject.setVoltage_V(Voltage_V);

				analyticsDataPCVInfoObjectList.add(analyticsDataPCVInfoObject);

			}
		} catch (SQLException e) {
			logger.error(e);
		}

		return analyticsDataPCVInfoObjectList;
	}

	public List<AnalyticsDataSOCnSOHInfoObject> getAnalyticsDataSOCnSOH(Connection connection, String devcieId) {
		PreparedStatement stmt;
		List<AnalyticsDataSOCnSOHInfoObject> analyticsDataSOCnSOHInfoObjectList = new ArrayList<AnalyticsDataSOCnSOHInfoObject>();
		try {
			stmt = connection.prepareStatement(DBQueries.descOrderedtblDeviceTransaction);
			stmt.setString(1, devcieId);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				AnalyticsDataSOCnSOHInfoObject analyticsDataSOCnSOHInfoObject = new AnalyticsDataSOCnSOHInfoObject();

				Date DeviceDisplayTime = rs.getDate("DeviceDisplayTime");
				logger.info("DeviceDisplayTime =" + DeviceDisplayTime);
				analyticsDataSOCnSOHInfoObject
						.setDateTime(new SimpleDateFormat("dd-MM-yyyy").format(DeviceDisplayTime));
				int soc = rs.getInt("SOC");
				logger.info("soc = " + soc);
				analyticsDataSOCnSOHInfoObject.setSOC(soc);
				int SOH = rs.getInt("SOH");
				logger.info("SOH = " + SOH);
				analyticsDataSOCnSOHInfoObject.setSOH(SOH);

				analyticsDataSOCnSOHInfoObjectList.add(analyticsDataSOCnSOHInfoObject);

			}
		} catch (SQLException e) {
			logger.error(e);
		}

		return analyticsDataSOCnSOHInfoObjectList;
	}

	public List<AnalyticsDataTHInfoObject> getAnalyticsDataTH(Connection connection, String devcieId) {
		PreparedStatement stmt;
		List<AnalyticsDataTHInfoObject> analyticsDataTHInfoObjectList = new ArrayList<AnalyticsDataTHInfoObject>();
		try {
			stmt = connection.prepareStatement(DBQueries.descOrderedtblDeviceTransaction);
			stmt.setString(1, devcieId);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				AnalyticsDataTHInfoObject analyticsDataTHInfoObject = new AnalyticsDataTHInfoObject();

				Date DeviceDisplayTime = rs.getDate("DeviceDisplayTime");
				logger.info("DeviceDisplayTime =" + DeviceDisplayTime);
				analyticsDataTHInfoObject.setDateTime(new SimpleDateFormat("dd-MM-yyyy").format(DeviceDisplayTime));
				int temperature = rs.getInt("Temperature");
				logger.info("temperature = " + temperature);
				analyticsDataTHInfoObject.setTemperature(temperature);
				int Humidity = rs.getInt("Humidity");
				logger.info("Humidity = " + Humidity);
				analyticsDataTHInfoObject.setHumidity(Humidity);

				analyticsDataTHInfoObjectList.add(analyticsDataTHInfoObject);

			}
		} catch (SQLException e) {
			logger.error(e);
		}

		return analyticsDataTHInfoObjectList;
	}
	public CycleCount getCycleCount(Connection connection, String devcieId) {
		PreparedStatement stmt;
		int count =0;
		int count1 =0;
		int cycles = 0;
		CycleCount cycleCount = new CycleCount();
		try {
			stmt = connection.prepareStatement(DBQueries.descOrderedtblDeviceTransaction);
			stmt.setString(1, devcieId);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				int soc = rs.getInt("SOC");
				logger.info("soc = " + soc);
				cycleCount.setSOC(soc);
				
				if(soc <= 100) {
					count = (100 - soc);
					logger.info("count = " + count);
					count1 = count1 + count;
					logger.info("count1 = " + count1);
				}
				if(count1 >= 100) {
					cycles = count1 % 100;
					cycleCount.setUsedCycleCount(cycles);
					logger.info("cycles = " + cycles);
				}

			}
		} catch (SQLException e) {
			logger.error(e);
		}

		return cycleCount;
	}

					
public ConfigurationFactors getConfigurationFactors(Connection connection, String devcieId) {
		
		ConfigurationFactors configuration = new ConfigurationFactors();
		try {
			
		
		List<AlertConfiguration> alertConfigurations = new ArrayList<AlertConfiguration>();
		    PreparedStatement stmt1 = connection.prepareStatement(DBQueries.alertConfigTransaction);
			logger.info("queeerrrrryyyy" + DBQueries.alertConfigTransaction);
		    stmt1.setString(1, devcieId);

			ResultSet rs1 = stmt1.executeQuery();
			if (rs1.next()) {
				AlertConfiguration alertConfiguration = new AlertConfiguration();
				String Name = rs1.getString("Name");
				logger.info("Name = " + Name);
				alertConfiguration.setName(Name);
				String Mobile = rs1.getString("Mobile");
				logger.info("Mobile = " + Mobile);
				alertConfiguration.setMobile(Mobile);
				String Email = rs1.getString("Email");
				logger.info("Email = " + Email);
				alertConfiguration.setEmail(Email);
				String CountryCode = rs1.getString("CountryID");
				logger.info("CountryCode = " + CountryCode);
				alertConfiguration.setCountryCode(CountryCode);
				

				alertConfigurations.add(alertConfiguration);
				configuration.setAlertConfig(alertConfigurations);

			}
			else {
			AlertConfiguration alertConfiguration1 = new AlertConfiguration();
			alertConfiguration1.setName("");
			alertConfiguration1.setMobile("");
			alertConfiguration1.setEmail("");
			alertConfiguration1.setCountryCode("");
			

			alertConfigurations.add(alertConfiguration1);
			configuration.setAlertConfig(alertConfigurations);
			}
		} catch (SQLException e) {
			logger.error(e);
		}

		return configuration;
	}
	
	public CountriesList getCountriesList(Connection connection) {
		PreparedStatement stmt;
		List<Countries> country = new ArrayList<Countries>();
		CountriesList countryList = new CountriesList();
		try {
			stmt = connection.prepareStatement(DBQueries.countryList);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Countries countries = new Countries();
				String ShortName = rs.getString("CountryShortName");
				logger.info("ShortName = " + ShortName);
				countries.setCountryShortName(ShortName);
				String Code = rs.getString("CountryCode");
				logger.info("CountryCode = " + Code);
				countries.setCountryCode(Code);
				
				country.add(countries);
				countryList.setCountries(country);
				}
			}
		 catch (SQLException e) {
			logger.error(e);
		}
		return countryList;
	
		
	}
	
	public DeviceInfoObject getDeviceDetails(Connection connection, String deviceId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public boolean getUserConfig(Connection connection, UserConfig config, DeviceConfig deviceconfig, AlertConfig alertconfig) {
		
		String userName = config.getUserName();
		String password = config.getPassword();
		int deviceID = deviceconfig.getDeviceID();
		logger.info("deeeee" + deviceID);
		int refreshRate = deviceconfig.getRefreshRate();
		String name = alertconfig.getName();
		String phone = alertconfig.getPhone();
		String countrycode = alertconfig.getCountryCode();
		String Email = alertconfig.getEmail();
		logger.info("Query = " + DBQueries.userMasterID);
		PreparedStatement stmt;
		int userID = 0;
		boolean userconfig = true;
		try {
			stmt = connection.prepareStatement(DBQueries.userMasterID);
			stmt.setString(1, userName);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int masterID = rs.getInt("UserMasterID");
				userID = rs.getInt("UserID");
				PreparedStatement stmt1 = connection.prepareStatement(DBQueries.updateUserConfig);
				stmt1.setString(1, password);
				stmt1.setInt(2, refreshRate);
				stmt1.setInt(3, masterID);
				stmt1.execute();
			
			boolean userValidation = UserManagementDAOImpl.checkForUserID(connection, rs.getInt("UserID"));
			if (userValidation == true) {
				PreparedStatement stmt2 = connection.prepareStatement(DBQueries.updateAlertconfig);
				stmt2.setString(1, name);
				stmt2.setString(2, phone);
				stmt2.setString(3, countrycode);
				stmt2.setString(4, Email);
				stmt2.setInt(5, deviceID);
				stmt2.setInt(6, userID);
				stmt2.execute();
			
			}
			else {
				PreparedStatement stmt4 = connection.prepareStatement(DBQueries.newUSer);
				stmt4.setInt(1, userID);
				stmt4.setString(2, name);
				stmt4.setString(3, phone);
				stmt4.setString(4, countrycode);
				stmt4.setString(5, Email);
				stmt4.setInt(6, deviceID);
				stmt4.execute();
			}
			}
		}
		catch (SQLException e) {
			logger.error(e);
		}
		return userconfig;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}