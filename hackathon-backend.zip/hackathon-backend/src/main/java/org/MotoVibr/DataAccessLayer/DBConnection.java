package org.MotoVibr.DataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;

import org.MotoVibr.Utilities.Config;
import org.apache.log4j.Logger;

/**
 * 
 * @author bhavya
 * 
 *         This class creates the connection with the DB.
 *
 */
public class DBConnection {

	static final Logger logger = Logger.getLogger(DBConnection.class);

	/**
	 * Creates connection with the DB
	 * 
	 * @return
	 */
	public Connection getConnection() {
		String databaseUrl = Config.getProperty("databaseUrl");
		String username = Config.getProperty("userName");
		String password = Config.getProperty("password");
		
		
		Connection connection = null; // For making the connection

		try {
			// Ensure the SQL Server driver class is available.
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Class.forName("com.mysql.jdbc.Driver");
			// Establish the connection.
			connection = DriverManager.getConnection(databaseUrl, username, password);

			if (connection != null) {
				logger.info("Connected");
			}
		} catch (Exception e) {
			logger.info("Exception " + e.getMessage());
			e.printStackTrace();
		}
		return connection;

	}

}

