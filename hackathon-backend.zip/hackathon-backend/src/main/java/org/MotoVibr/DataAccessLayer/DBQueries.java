package org.MotoVibr.DataAccessLayer;

/**
 * 
 * @author bhavya
 * 
 *         Constants used across project
 *
 */
public class DBQueries {

	public static final String tblUserMasterOnUserNamePassword = "select * from motovibr.tblusermaster where UserName = ? and Password = ?";
	
	public static final String Authentication = "select u.UserName, d.Password from motovibr.tblusermaster u, motovibr.tbluserdetailstransaction d where u.userMasterID=d.UserMasterID and u.UserName = ? and d.Password = ?";

	public static final String tblUserMasterOnUserName = "select * from motovibr.tblusermaster where UserName = ?";

	public static final String tblDeviceMasterOnDeviceId = "select * from motovibr.tbldevicemaster where DeviceID = ?";

	public static final String allTblDeviceMaster = "select * from motovibr.tbldevicemaster";
	
	public static final String TotalNumberOfDevices = "select count(*) from motovibr.tbldevicemaster";
	
	public static final String TotalAlertCount = "select count(*) from motovibr.tblalerttransaction";
	
	public static final String PriorityType = "select PriorityType,count(PriorityType) as Count_Of_PriorityType from motovibr.tblalertmaster Group by PriorityType";
	
	public static final String DeviceHealth = "select DeviceHealth,count(DeviceHealth) as Count_Of_Health from motovibr.tbldevicemaster Group by DeviceHealth";
	
	public static final String DeviceStatus = "select DeviceStatus,count(DeviceStatus) as Count_Of_Status from motovibr.tbldevicemaster Group by DeviceStatus";
	
	public static final String recentDataFromtblDeviceTransaction = "select DevicePacketTime from motovibr.tbldevicetransaction where DeviceID = ? group by DeviceID ";

	public static final String tblAlertMasterOnAlertId = "select a.DeviceID, b.* from motovibr.tblalerttransaction a, motovibr.tblalertmaster b where a.AlertID = b.AlertID";

	public static final String allTblAlertTransaction = "select * from motovibr.tblalerttransaction order by AlertPacketTime desc";

	public static final String tblAlertTransactionOnAlertId = "select * from motovibr.tblalerttransaction where AlertID= ?";

	public static final String allTblAlertMaster = "select * from motovibr.tblalertmaster";

	public static final String tblDeviceTransactionOnAvg = "select avg(Current_Amp) as Average_Current_A,avg(Voltage_Volt) as Average_Voltage_V ,avg(Power_Watt) as Average_Power_W ,avg(SOC) as Average_SOC,avg(SOH) as Average_SOH FROM motovibr.tbldevicetransaction";

	public static final String tblDeviceTransactionForADeviceOnAvg = "select avg(Current_Amp) as Average_Current_A,avg(Voltage_Volt) as Average_Voltage_V ,avg(Power_Watt) as Average_Power_W FROM motovibr.tbldevicetransaction where [DeviceID] = ?";

	public static final String alltblAlertTransaction = "select * FROM motovibr.tblalerttransaction";
	
	public static final String descOrderedtblDeviceTransaction = "select * from dbo.tblDeviceTransaction where deviceID = ? order by DeviceDisplayTime desc";

	public static final String alertConfigTransaction = "select * from motovibr.tblalertconfigtransaction where DeviceID = ?";
	
	public static final String countryList = "select * from motovibr.tblcountrymaster";
	
	public static final String userMasterID = "select a.UserMasterID, b.USerID from motovibr.tblusermaster a, motovibr.tbluserdetailstransaction b where a.UserMasterID = b.USerMasterID and UserName = ?";
	
	public static final String updateUserConfig = "update motovibr.tbluserdetailstransaction set Password = ?, RefreshRate = ? where UserMasterID = ?";

	public static final String updateAlertconfig = "update motovibr.tblalertconfigtransaction set Name = ?, Mobile = ?, MobileCode = ?, Email = ?, DeviceID = ? where UserID = ?";

	public static final String userIDAlertConfigTransaction = "select UserID from motovibr.tblalertconfigtransaction where UserID = ?";

	public static final String newUSer = "insert into motovibr.tblalertconfigtransaction( UserID, Name, Mobile, MobileCode, Email, DeviceID) values (?, ?, ?, ?, ?, ?)";

	public static final String tblAlertConfOnUserID = "select * from motovibr.tblalertconfigtransaction where UserID = ?";
}
