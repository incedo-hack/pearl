package org.MotoVibr.InfoObject;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = { "CountryShortName", "CountryCode"})
public class Countries {

	protected String CountryShortName;
	protected String CountryCode;
	
	public String getCountryShortName() {
		return CountryShortName;
	}
	public void setCountryShortName(String countryShortName) {
		CountryShortName = countryShortName;
	}
	public String getCountryCode() {
		return CountryCode;
	}
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}

	
	
	
	

}
