package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author bhavya
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Marker", propOrder = { "Location_X", "Location_Y", "Location" })
public class LocationInfoObject {

	@XmlElement(required = true)
	protected int Location_X;
	@XmlElement(required = true)
	protected int Location_Y;
	protected String Location;
	
	public int getLocation_X() {
		return Location_X;
	}
	public void setLocation_X(int location_X) {
		Location_X = location_X;
	}
	public int getLocation_Y() {
		return Location_Y;
	}
	public void setLocation_Y(int location_Y) {
		Location_Y = location_Y;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}

	

}
