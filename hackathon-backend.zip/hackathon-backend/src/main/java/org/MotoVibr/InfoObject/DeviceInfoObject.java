package org.MotoVibr.InfoObject;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * @author bhavya
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "DeviceName", "Current_A", "Voltage_V", "Power_W", "DisplayTime",
		"Average", "Marker" })
public class DeviceInfoObject {

	protected String DeviceName;
	protected int Current_A;
	protected int Voltage_V;
	protected int Power_W;
	//protected String DisplayTime;
	protected Date DisplayTime;
	protected AllDeviceDetailInfoObject Average;
	protected LocationInfoObject Marker;

	public String getDeviceName() {
		return DeviceName;
	}

	public void setDeviceName(String deviceName) {
		DeviceName = deviceName;
	}

	public int getCurrent_A() {
		return Current_A;
	}

	public void setCurrent_A(int current_A) {
		Current_A = current_A;
	}

	public int getVoltage_V() {
		return Voltage_V;
	}

	public void setVoltage_V(int voltage_V) {
		Voltage_V = voltage_V;
	}

	public int getPower_W() {
		return Power_W;
	}

	public void setPower_W(int power_W) {
		Power_W = power_W;
	}

	public Date getDisplayTime() {
		return DisplayTime;
	}

	public void setDisplayTime(Date date) {
		this.DisplayTime = date;
	}

	public AllDeviceDetailInfoObject getAverage() {
		return Average;
	}

	public void setAverage(AllDeviceDetailInfoObject average) {
		this.Average = average;
	}

	public LocationInfoObject getMarker() {
		return Marker;
	}

	public void setMarker(LocationInfoObject marker) {
		Marker = marker;
	}

}
