package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author rahil
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlertList", propOrder = { "X_Value", "Y_Value", "Z_Value", "Temprature", "Voltage_Volt"
		+ "Power_Watt", "Current_Amp", "Humidity" })
public class SelcetedAlertInfo {

	@XmlElement(required = true)
	protected int X_Value;
	protected int Y_Value;
	protected int Z_Value;
	protected int Temprature;
	protected int Voltage_Volt;
	protected int Power_Watt;
	protected int Current_Amp;
	protected int Humidity;
	public int getX_Value() {
		return X_Value;
	}
	public void setX_Value(int x_Value) {
		X_Value = x_Value;
	}
	public int getY_Value() {
		return Y_Value;
	}
	public void setY_Value(int y_Value) {
		Y_Value = y_Value;
	}
	public int getZ_Value() {
		return Z_Value;
	}
	public void setZ_Value(int z_Value) {
		Z_Value = z_Value;
	}
	public int getTemprature() {
		return Temprature;
	}
	public void setTemprature(int temprature) {
		Temprature = temprature;
	}
	public int getVoltage_Volt() {
		return Voltage_Volt;
	}
	public void setVoltage_Volt(int voltage_Volt) {
		Voltage_Volt = voltage_Volt;
	}
	public int getPower_Watt() {
		return Power_Watt;
	}
	public void setPower_Watt(int power_Watt) {
		Power_Watt = power_Watt;
	}
	public int getCurrent_Amp() {
		return Current_Amp;
	}
	public void setCurrent_Amp(int current_Amp) {
		Current_Amp = current_Amp;
	}
	public int getHumidity() {
		return Humidity;
	}
	public void setHumidity(int humidity) {
		Humidity = humidity;
	}
	

	


}
