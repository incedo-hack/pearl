package org.MotoVibr.InfoObject;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = { "MaxCycleCount", "UsedCycleCount", "SOC" })
public class CycleCount {

	protected int MaxCycleCount;
	protected int UsedCycleCount;
	protected int SOC;
	
	public int getSOC() {
		return SOC;
	}
	public void setSOC(int sOC) {
		SOC = sOC;
	}
	public int getMaxCycleCount() {
		return MaxCycleCount;
	}
	public void setMaxCycleCount(int maxCycleCount) {
		MaxCycleCount = maxCycleCount;
	}
	public int getUsedCycleCount() {
		return UsedCycleCount;
	}
	public void setUsedCycleCount(int usedCycleCount) {
		UsedCycleCount = usedCycleCount;
	}

	

}
