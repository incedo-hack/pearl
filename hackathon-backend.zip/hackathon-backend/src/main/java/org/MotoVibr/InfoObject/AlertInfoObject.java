package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
/**
 * 
 * @author bhavya
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Alert", propOrder = { "Priority", "Name","AlertType", "PriorityType", "AlertDescription","OccuranceTime", "Marker" })
public class AlertInfoObject {

	@XmlElement(required = true)
	protected String Priority;
	@XmlElement(required = true)
	protected String Name;
	protected String AlertType;
	@XmlElement(required = true)
	protected Object PriorityType;
	@XmlElement(required = true)
	protected String AlertDescription;
	protected String OccuranceTime;
	@XmlElement(required = true)
	protected SelcetedAlertInfo Marker;
	
	
	public String getOcuuranceTime() {
		return OccuranceTime;
	}

	public void setOccuranceTime(String ocuuranceTime) {
		OccuranceTime = ocuuranceTime;
	}

	public String getAlertType() {
		return AlertType;
	}

	public void setAlertType(String alertType) {
		AlertType = alertType;
	}

	public String getPriority() {
		return Priority;
	}

	public void setPriority(String priority) {
		Priority = priority;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public Object getPriorityType() {
		return PriorityType;
	}

	public void setPriorityType(Object priorityType) {
		PriorityType = priorityType;
	}

	public SelcetedAlertInfo getMarker() {
		return Marker;
	}

	public void setMarker(SelcetedAlertInfo marker) {
		Marker = marker;
	}

	public String getAlertDescription() {
		return AlertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		AlertDescription = alertDescription;
	}

}
