package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = {"AlertConfig"})

public class ConfigurationFactors {

	protected Object AlertConfig;
	
	public Object getAlertConfig() {
		return AlertConfig;
	}
	public void setAlertConfig(Object alertConfig) {
		AlertConfig = alertConfig;
	}
	
}