package org.MotoVibr.InfoObject;


import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "TotalAlertCount", "Alerts" })
public class AllAlertCount {

	protected int TotalAlertCount;
	protected List<AlertStatusInfoObject> Alerts;
	
	public int getTotalAlertCount() {
		return TotalAlertCount;
	}
	public void setTotalAlertCount(int totalAlertCount) {
		TotalAlertCount = totalAlertCount;
	}
	public List<AlertStatusInfoObject> getAlerts() {
		return Alerts;
	}
	public void setAlerts(List<AlertStatusInfoObject> alerts) {
		Alerts = alerts;
	}
	

	

}

