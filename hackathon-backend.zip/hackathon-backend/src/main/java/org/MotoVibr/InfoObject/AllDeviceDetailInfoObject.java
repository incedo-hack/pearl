package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "allDeviceDetail", propOrder = { "Average_Current_A", "Average_Voltage_V", "Average_Power_W",
		"Average_SOC", "Average_SOH" })
public class AllDeviceDetailInfoObject {

	@XmlElement(required = true)
	protected int Average_Current_A;
	@XmlElement(required = true)
	protected int Average_Voltage_V;
	@XmlElement(required = true)
	protected int Average_Power_W;
	@XmlElement(required = true)
	protected int Average_SOC;
	@XmlElement(required = true)
	protected int Average_SOH;

	public int getAverage_Current_A() {
		return Average_Current_A;
	}

	public void setAverage_Current_A(int average_Current_A) {
		Average_Current_A = average_Current_A;
	}

	public int getAverage_Voltage_V() {
		return Average_Voltage_V;
	}

	public void setAverage_Voltage_V(int average_Voltage_V) {
		Average_Voltage_V = average_Voltage_V;
	}

	public int getAverage_Power_W() {
		return Average_Power_W;
	}

	public void setAverage_Power_W(int average_Power_W) {
		Average_Power_W = average_Power_W;
	}

	public int getAverage_SOC() {
		return Average_SOC;
	}

	public void setAverage_SOC(int average_SOC) {
		Average_SOC = average_SOC;
	}

	public int getAverage_SOH() {
		return Average_SOH;
	}

	public void setAverage_SOH(int average_SOH) {
		Average_SOH = average_SOH;
	}

}
