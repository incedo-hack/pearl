package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author bhavya
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlertList", propOrder = { "DeviceID", "Alert" })
public class AllAlertsInfoObject {

	@XmlElement(required = true)
	protected String DeviceID;
	@XmlElement(required = true)
	protected AlertInfoObject Alert;

	public String getDeviceID() {
		return DeviceID;
	}

	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}

	public AlertInfoObject getAlert() {
		return Alert;
	}

	public void setAlert(AlertInfoObject Alert) {
		this.Alert = Alert;
	}

}
