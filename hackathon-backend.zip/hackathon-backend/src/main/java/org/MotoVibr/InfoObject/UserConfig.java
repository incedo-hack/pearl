package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * @author rahil
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "UserName", "Password"})
public class UserConfig {

	protected String UserName;
	protected String Password;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
}



