package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = { "Countries"})
public class CountriesList {

	protected Object Countries;

	public Object getCountries() {
		return Countries;
	}

	public void setCountries(Object countries) {
		Countries = countries;
	}
	
	
	

}