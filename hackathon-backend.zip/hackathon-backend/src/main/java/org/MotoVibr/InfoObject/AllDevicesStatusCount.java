package org.MotoVibr.InfoObject;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "TotalBatteryCount", "DeviceHealthStatus", "DeviceWorkingStatus" })
public class AllDevicesStatusCount {

	protected int TotalBatteryCount;
	protected List<BatteryStatusInfoObject> DeviceHealthStatus;
	protected List<BatteryChargerStatusInfoObject> DeviceWorkingStatus;

	
	public List<BatteryStatusInfoObject> getDeviceHealthStatus() {
		return DeviceHealthStatus;
	}

	public void setDeviceHealthStatus(List<BatteryStatusInfoObject> deviceHealthStatus) {
		DeviceHealthStatus = deviceHealthStatus;
	}

	public List<BatteryChargerStatusInfoObject> getDeviceWorkingStatus() {
		return DeviceWorkingStatus;
	}

	public void setDeviceWorkingStatus(List<BatteryChargerStatusInfoObject> deviceWorkingStatus) {
		DeviceWorkingStatus = deviceWorkingStatus;
	}

	public int getTotalBatteryCount() {
		return TotalBatteryCount;
	}

	public void setTotalBatteryCount(int totalBatteryCount) {
		TotalBatteryCount = totalBatteryCount;
	}

}

