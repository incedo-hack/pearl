package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author bhavya
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateConfig", propOrder = { "UserConfig", "DeviceConfig", "AlertConfig" })
public class UpdateConfig {

	@XmlElement(required = true)
	protected UserConfig UserConfig;
	@XmlElement(required = true)
	protected DeviceConfig DeviceConfig;
	@XmlElement(required = true)
	protected AlertConfig AlertConfig;
	
	public UserConfig getUserConfig() {
		return UserConfig;
	}
	public void setUserConfig(UserConfig userConfig) {
		UserConfig = userConfig;
	}
	
	public DeviceConfig getDeviceConfig() {
		return DeviceConfig;
	}
	public void setDeviceConfig(DeviceConfig deviceConfig) {
		DeviceConfig = deviceConfig;
	}
	public AlertConfig getAlertConfig() {
		return AlertConfig;
	}
	public void setAlertConfig(AlertConfig alertConfig) {
		AlertConfig = alertConfig;
	}
	
}

