package org.MotoVibr.InfoObject;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Rahil
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BatteryHealth", propOrder = { "State", "Value", "Color" })
public class AlertStatusInfoObject {

	@XmlElement(required = true)
	protected String State;
	protected int Value;
	protected String Color;
	
	public String getColor() {
		return Color;
	}

	public void setColor(String color) {
		Color = color;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getValue() {
		return Value;
	}

	public void setValue(int value) {
		Value = value;
	}
}