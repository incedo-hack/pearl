package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * @author rahil
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "DeviceID", "RefreshRate"})
public class DeviceConfig {

	protected int DeviceID;
	protected int RefreshRate;
	
	public int getDeviceID() {
		return DeviceID;
	}
	public void setDeviceID(int deviceID) {
		DeviceID = deviceID;
	}
	public int getRefreshRate() {
		return RefreshRate;
	}
	public void setRefreshRate(int refreshRate) {
		RefreshRate = refreshRate;
	}
	
}

