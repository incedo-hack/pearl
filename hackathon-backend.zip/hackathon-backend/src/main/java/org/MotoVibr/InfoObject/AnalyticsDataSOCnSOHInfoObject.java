package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = { "DateTime", "SOC", "SOH" })
public class AnalyticsDataSOCnSOHInfoObject {

	protected String DateTime;
	protected int SOC;
	protected int SOH;

	public String getDateTime() {
		return DateTime;
	}

	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}

	public int getSOC() {
		return SOC;
	}

	public void setSOC(int sOC) {
		SOC = sOC;
	}

	public int getSOH() {
		return SOH;
	}

	public void setSOH(int sOH) {
		SOH = sOH;
	}

}
