package org.MotoVibr.InfoObject;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "device", propOrder = { "DeviceID", "DeviceName", "DeviceStatus", "DisplayTime", "Marker"})
public class AllDeviceListInfoObject {

	protected String DeviceID;
	protected String DeviceName;
	protected Object DeviceStatus;
	//protected String DisplayTime;
	protected String DisplayTime;
	protected LocationInfoObject Marker;

	public String getDeviceID() {
		return DeviceID;
	}

	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}

	public String getDeviceName() {
		return DeviceName;
	}

	public void setDeviceName(String deviceName) {
		DeviceName = deviceName;
	}

	public Object getDeviceStatus() {
		return DeviceStatus;
	}

	public void setDeviceStatus(Object deviceStatus) {
		DeviceStatus = deviceStatus;
	}

	public String getDisplayTime() {
		return DisplayTime;
	}

	public void setDisplayTime(String displayTime) {
		DisplayTime = displayTime;
	}

	public LocationInfoObject getMarker() {
		return Marker;
	}

	public void setMarker(LocationInfoObject marker) {
		Marker = marker;
	}
	
}
