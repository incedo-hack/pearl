package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnalyticsDataPCV", propOrder = { "DateTime", "Current_A", "Power_W", "Voltage_V" })
public class AnalyticsDataPCVInfoObject {

	protected String DateTime;
	protected int Current_A;
	protected int Power_W;
	protected int Voltage_V;

	public String getDateTime() {
		return DateTime;
	}

	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}

	public int getCurrent_A() {
		return Current_A;
	}

	public void setCurrent_A(int current_A) {
		Current_A = current_A;
	}

	public int getPower_W() {
		return Power_W;
	}

	public void setPower_W(int power_W) {
		Power_W = power_W;
	}

	public int getVoltage_V() {
		return Voltage_V;
	}

	public void setVoltage_V(int voltage_V) {
		Voltage_V = voltage_V;
	}

}
