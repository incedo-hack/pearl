package org.MotoVibr.InfoObject;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;



	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "AnalyticsDataSOCnSOH", propOrder = { "Name", "Mobile", "CountryCode", "Email"})
	public class AlertConfiguration {
		
		protected String Mobile;
		protected String Name;
		protected String CountryCode;
		protected String Email;
		
		public String getMobile() {
			return Mobile;
		}
		public void setMobile(String mobile) {
			Mobile = mobile;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getCountryCode() {
			return CountryCode;
		}
		public void setCountryCode(String countryCode) {
			CountryCode = countryCode;
		}
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}

		
	}
		