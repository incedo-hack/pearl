package org.MotoVibr.InfoObject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 
 * @author Rahil
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BatteryHealth", propOrder = { "AlertName", "AlertType", "PriorityType", "AlertDescription" })
public class AlertsInfo {

	@XmlElement(required = true)
	protected String AlertName;
	protected String AlertType;
	protected int PriorityType;
	protected String AlertDescription;
	public String getAlertName() {
		return AlertName;
	}
	public void setAlertName(String alertName) {
		AlertName = alertName;
	}
	public String getAlertType() {
		return AlertType;
	}
	public void setAlertType(String alertType) {
		AlertType = alertType;
	}
	public int getPriorityType() {
		return PriorityType;
	}
	public void setPriorityType(int priorityType) {
		PriorityType = priorityType;
	}
	public String getAlertDescription() {
		return AlertDescription;
	}
	public void setAlertDescription(String alertDescription) {
		AlertDescription = alertDescription;
	}
	
	
}